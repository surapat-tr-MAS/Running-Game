/* ไคลเอนต์ฝั่งผู้เล่น — ส่งการกดปุ่ม WASD ขึ้นเซิร์ฟเวอร์และแสดงรางจังหวะ 60fps */

import { makeView, runLoop } from './shared/view.js';
import { createRhythmUI } from './shared/rhythm.js';
import { TEAM_COLORS, RULES, TRACK } from './shared/track.js';

const $ = id => document.getElementById(id);
const sock = io({ transports: ['websocket', 'polling'] });
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const S = {
  token: localStorage.getItem('runningGame.token') || '',
  name: localStorage.getItem('runningGame.name') || '',
  slot: null,
  phase: 'lobby',
  seats: [],
  lobby: null,
  trackMeters: TRACK.defaultMeters,
  playStartSrvMs: 0,
  playing: false,
};

let view = null, viewReady = null;
let rhythm = null;
let clockOffset = 0, bestRtt = Infinity;

/* ---------------- ซิงค์นาฬิกากับเซิร์ฟเวอร์ ---------------- */
function pingClock() {
  const p0 = performance.now();
  sock.emit('time:ping', p0, res => {
    if (!res) return;
    const p1 = performance.now();
    const rtt = p1 - p0;
    const sample = res.srvMs - (p0 + rtt / 2);
    if (bestRtt === Infinity || rtt <= bestRtt * 1.35) {
      clockOffset = bestRtt === Infinity ? sample : clockOffset * 0.65 + sample * 0.35;
      bestRtt = Math.min(bestRtt, rtt);
    }
  });
}

function estSrvMs() {
  return performance.now() + clockOffset;
}

function getElapsedMs() {
  if (!S.playing || !S.playStartSrvMs) return 0;
  return Math.max(0, estSrvMs() - S.playStartSrvMs);
}

/* ---------------- สลับหน้าจอ ---------------- */
function show(which) {
  $('joinScreen').style.display = which === 'join' ? '' : 'none';
  $('lobbyScreen').style.display = which === 'lobby' ? '' : 'none';
  $('gameScreen').classList.toggle('show', which === 'game');
}

/* ---------------- เข้าร่วม ---------------- */
$('nameInput').value = S.name;
$('nameInput').addEventListener('keydown', e => { if (e.key === 'Enter') join(); });
$('joinBtn').addEventListener('click', join);

function join() {
  const name = $('nameInput').value.trim();
  if (!name) { $('joinErr').textContent = 'กรุณาใส่ชื่อผู้เล่น'; return; }
  $('joinBtn').disabled = true;
  sock.emit('join', { name, token: S.token }, res => {
    $('joinBtn').disabled = false;
    if (!res?.ok) { $('joinErr').textContent = res?.msg || 'เข้าร่วมไม่สำเร็จ'; return; }
    S.token = res.token;
    S.name = res.name;
    S.slot = res.slot;
    localStorage.setItem('runningGame.token', S.token);
    localStorage.setItem('runningGame.name', S.name);
    $('whoami').textContent = S.name;
    show(S.phase === 'playing' || S.phase === 'countdown' ? 'game' : 'lobby');
  });
}

/* ---------------- ล็อบบี้และสถานะรอบ ---------------- */
sock.on('hello', d => {
  if (d?.srvMs) {
    clockOffset = d.srvMs - performance.now();
    for (let i = 0; i < 4; i++) setTimeout(pingClock, i * 250);
  }
  applyLobby(d.lobby);
  if (S.token && S.name) join();
});
setInterval(() => { if (sock.connected) pingClock(); }, 6000);

sock.on('lobby', applyLobby);

function applyLobby(L) {
  if (!L) return;
  S.lobby = L;
  const prevPhase = S.phase;
  S.phase = L.phase;
  S.trackMeters = L.trackMeters || TRACK.defaultMeters;
  S.playing = L.phase === 'playing';
  if (L.round?.playStartSrvMs) S.playStartSrvMs = L.round.playStartSrvMs;

  const me = L.players.find(p => p.token === S.token);
  const PHASE_TH = { lobby: 'รอเริ่มรอบ', countdown: 'นับถอยหลัง', playing: 'กำลังแข่ง', result: 'ประกาศผล' };
  $('phasePill').innerHTML =
    '<span class="dot ' + (sock.connected ? 'on' : 'off') + '"></span>' +
    '<span>' + (PHASE_TH[L.phase] || L.phase) + '</span>';
  $('heatPill').textContent = me && me.heat >= 0 ? 'สายที่ ' + (me.heat + 1) : 'ยังไม่ได้แบ่งสาย';
  $('distPill').textContent = 'ระยะ ' + S.trackMeters + ' ม.';

  // ตารางคะแนนรวม
  const tb = $('totalBody');
  tb.innerHTML = '';
  [...L.players]
    .sort((a, b) => b.total - a.total || (a.bestTime ?? 9999) - (b.bestTime ?? 9999))
    .forEach((p, i) => {
      const tr = document.createElement('tr');
      if (p.token === S.token) tr.className = 'me';
      tr.innerHTML =
        '<td>' + (i + 1) + '</td>' +
        '<td>' + esc(p.name) + (p.isBot ? ' <span class="muted">[บอท]</span>' : p.online ? '' : ' <span class="muted">(หลุด)</span>') + '</td>' +
        '<td class="num">' + (p.heat >= 0 ? p.heat + 1 : '—') + '</td>' +
        '<td class="num">' + p.wins + '</td>' +
        '<td class="num">' + (p.bestTime !== null ? p.bestTime.toFixed(2) + 's' : '—') + '</td>' +
        '<td class="num"><b>' + p.total + '</b></td>';
      tb.appendChild(tr);
    });

  if (L.lastResult) {
    $('lastResultCard').style.display = '';
    const lb = $('lastBody');
    lb.innerHTML = '';
    L.lastResult.rank.forEach(r => {
      const tr = document.createElement('tr');
      if (r.token === S.token) tr.className = 'me';
      const perfStr = r.finished ? r.finishTime.toFixed(2) + 's' : r.dist + ' ม.';
      tr.innerHTML =
        '<td>' + r.rank + '</td>' +
        '<td><span class="swatch" style="background:' + TEAM_COLORS[r.slot] + '"></span> ' + esc(r.name) + '</td>' +
        '<td class="num">' + perfStr + '</td>' +
        '<td class="num">x' + r.maxStreak + '</td>' +
        '<td class="num"><b>' + r.score + '</b></td>';
      lb.appendChild(tr);
    });
  }

  if (!S.token) { show('join'); return; }

  if (L.phase === 'playing' || L.phase === 'countdown') {
    if (L.round?.seats?.length) enterRound(L.round);
    else show('game');
  } else if (prevPhase === 'playing' || prevPhase === 'countdown' || prevPhase !== L.phase) {
    show('lobby');
  }
}

async function enterRound(d) {
  S.seats = d.seats || [];
  S.trackMeters = d.trackMeters || S.trackMeters;
  if (d.playStartSrvMs) S.playStartSrvMs = d.playStartSrvMs;

  const mine = S.seats.find(s => s.token === S.token);
  S.slot = mine ? mine.slot : null;

  show('game');
  $('slotPill').innerHTML = S.slot === null
    ? 'คุณเป็นผู้ชม'
    : '<span class="swatch" style="background:' + TEAM_COLORS[S.slot] + '"></span> ลู่ ' + (S.slot + 1);
  $('rhythmDock').classList.toggle('show', S.slot !== null);
  $('camPill').style.display = S.slot !== null ? '' : 'none';
  $('distHudPill').textContent = '0 / ' + S.trackMeters + ' ม.';

  await ensureView();
  if (view) {
    view.setTrackMeters?.(S.trackMeters);
    view.setFollow(S.slot ?? -1);
    view.setCamMode(S.slot !== null ? 'follow' : 'broadcast');
    view._overview = false;
    $('camPill').textContent = 'มุมกล้อง: ตามตัว';
  }
  rhythm?.resize();
  if (S.slot === null) sock.emit('spectate');
}

async function ensureView() {
  if (viewReady) return viewReady;
  viewReady = (async () => {
    const cv = $('cv');
    view = await makeView(cv, { antialias: true, trackMeters: S.trackMeters });
    if (!rhythm) {
      rhythm = createRhythmUI($('rhythmCv'));
      rhythm.setElapsedProvider(getElapsedMs);
      rhythm.resize();
      addEventListener('resize', () => rhythm.resize());
    }
    runLoop(view, cv, () => {
      if (S.slot !== null && $('rhythmDock').classList.contains('show')) {
        rhythm.draw();
      }
    });
    $('fpsPill').textContent = view.kind === '3d' ? '3 มิติ' : 'โหมดประหยัด';
    $('fpsPill').onclick = () => {
      location.search = '?' + (view.kind === '3d' ? '2d' : '3d') + '=1';
    };
    return view;
  })();
  return viewReady;
}

/* ---------------- เหตุการณ์ระหว่างแข่ง ---------------- */
sock.on('begin', async d => {
  S.playing = false;
  S.playStartSrvMs = 0;
  await enterRound(d);
  overlay(null);
});

sock.on('countdown', n => {
  if (n > 0) {
    rhythm?.playCue('countdown');
    overlay({ big: String(n), text: 'เตรียมตัว! วางนิ้วบน W A S D' });
  } else {
    overlay(null);
  }
});

sock.on('go', d => {
  S.playing = true;
  S.playStartSrvMs = d.playStartSrvMs;
  S.trackMeters = d.trackMeters || S.trackMeters;
  overlay(null);
  rhythm?.playCue('go');
});

sock.on('rhythm', data => {
  rhythm?.applyRhythm(data);
  if (!data) return;

  $('spdVal').textContent = data.speed.toFixed(1);
  $('stkVal').textContent = 'x' + data.streak;
  $('lvVal').textContent = 'Lv.' + (data.level + 1);
  const bpm = Math.round(60000 / (data.beatMs || RULES.maxBeatMs));
  $('bpmVal').textContent = '(' + bpm + ' BPM)';
  $('tempoFill').style.width = Math.round((data.level / RULES.maxLevel) * 100) + '%';

  if (data.finished) {
    rhythm?.playCue('finish');
    overlay({
      big: 'เข้าเส้นชัย! อันดับ ' + data.place,
      text: 'เวลา ' + data.finishTime.toFixed(2) + ' วินาที · รอผู้เล่นคนอื่นเข้าเส้นชัย…',
      soft: true,
    });
  }
});

sock.on('state', snap => {
  if (!view) return;
  const names = [];
  S.seats.forEach(s => { names[s.slot] = s.name; });
  view.apply(snap, { names });

  $('clock').textContent = (snap.t / 1000).toFixed(1) + 's';

  const mine = S.slot === null ? null : snap.r.find(r => r[0] === S.slot);
  if (mine) {
    const dist = (mine[1] / 50).toFixed(1);
    const spd = (mine[2] / 50).toFixed(1);
    $('distHudPill').textContent = dist + ' / ' + snap.m + ' ม.';
    $('rankPill').textContent = 'อันดับ ' + mine[7] + '/' + snap.r.length;
    $('spdVal').textContent = spd;
  }

  const rows = [...snap.r].sort((a, b) => a[7] - b[7]);
  $('miniBody').innerHTML = rows
    .map(r => {
      const nm = (names[r[0]] || 'ลู่ ' + (r[0] + 1)).slice(0, 12);
      const dist = (r[1] / 50).toFixed(0);
      const fin = r[5] & 1;
      return (
        '<tr>' +
        '<td>' + r[7] + '.</td>' +
        '<td><span class="swatch" style="background:' + TEAM_COLORS[r[0]] + '"></span> ' + esc(nm) + '</td>' +
        '<td class="num">' + (fin ? (r[6] / 1000).toFixed(1) + 's' : dist + 'm') + '</td>' +
        '</tr>'
      );
    })
    .join('');
});

sock.on('result', res => {
  S.playing = false;
  const mineRow = res.rank.find(r => r.token === S.token);
  const table =
    '<table><thead><tr><th>#</th><th>นักวิ่ง</th><th class="num">เวลา/ระยะ</th>' +
    '<th class="num">Streak</th><th class="num">แม่นยำ</th><th class="num">คะแนน</th></tr></thead><tbody>' +
    res.rank
      .map(
        r =>
          '<tr' + (r.token === S.token ? ' class="me"' : '') + '><td>' + r.rank + '</td>' +
          '<td><span class="swatch" style="background:' + TEAM_COLORS[r.slot] + '"></span> ' + esc(r.name) + '</td>' +
          '<td class="num">' + (r.finished ? r.finishTime.toFixed(2) + 's' : r.dist + ' ม.') + '</td>' +
          '<td class="num">x' + r.maxStreak + '</td>' +
          '<td class="num">' + r.accuracy + '%</td>' +
          '<td class="num"><b>' + r.score + '</b></td></tr>',
      )
      .join('') +
    '</tbody></table>';

  overlay({
    big: mineRow ? 'อันดับ ' + mineRow.rank : 'จบรอบ',
    text: res.reason + ' · สายที่ ' + (res.heatIndex + 1) + ' (' + res.trackMeters + ' ม.)',
    html: table,
  });
});

function overlay(o) {
  const el = $('overlay');
  if (!o) { el.style.display = 'none'; return; }
  el.style.display = '';
  $('ovBig').textContent = o.big || '';
  $('ovText').textContent = o.text || '';
  $('ovTable').innerHTML = o.html || '';
  el.style.background = o.soft ? 'rgba(8,12,17,.48)' : 'rgba(8,12,17,.78)';
}

/* ---------------- การกดปุ่ม WASD ---------------- */
const KEY_MAP = {
  KeyW: 'W', ArrowUp: 'W',
  KeyA: 'A', ArrowLeft: 'A',
  KeyS: 'S', ArrowDown: 'S',
  KeyD: 'D', ArrowRight: 'D',
};

function tapKey(key) {
  if (!key) return;
  rhythm?.flashKey(key);
  const btn = document.querySelector(`.wasdBtn[data-k="${key}"]`);
  if (btn) {
    btn.classList.add('lit');
    setTimeout(() => btn.classList.remove('lit'), 110);
  }
  if (!S.playing || S.slot === null) return;
  sock.emit('tap', { key, at: Math.round(estSrvMs()) });
}

addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
  if (e.code === 'KeyC' && view && S.slot !== null) {
    view._overview = !view._overview;
    view.setCamMode(view._overview ? 'overview' : 'follow');
    $('camPill').textContent = view._overview ? 'มุมกล้อง: ทั้งสนาม' : 'มุมกล้อง: ตามตัว';
    return;
  }
  const k = KEY_MAP[e.code];
  if (!k || e.repeat) return;
  e.preventDefault();
  tapKey(k);
});

for (const btn of document.querySelectorAll('.wasdBtn')) {
  btn.addEventListener('pointerdown', e => {
    e.preventDefault();
    tapKey(btn.dataset.k);
  });
}

$('soundPill').addEventListener('click', () => {
  if (!rhythm) return;
  const m = !rhythm.isMuted();
  rhythm.setMuted(m);
  $('soundPill').textContent = m ? 'เสียง: ปิด' : 'เสียง: เปิด';
});

$('camPill').addEventListener('click', () => {
  if (!view) return;
  view._overview = !view._overview;
  view.setCamMode(view._overview ? 'overview' : 'follow');
  $('camPill').textContent = view._overview ? 'มุมกล้อง: ทั้งสนาม' : 'มุมกล้อง: ตามตัว';
});

sock.on('disconnect', () => {
  $('phasePill').innerHTML = '<span class="dot off"></span><span>ขาดการเชื่อมต่อ — กำลังต่อใหม่</span>';
});
