/* จอควบคุมของโฮสต์ / ครู — แบ่งสาย ปรับระยะทาง เพิ่มบอท และฉายสนามขึ้นโปรเจกเตอร์ */

import { makeView, runLoop } from './shared/view.js';
import { TEAM_COLORS } from './shared/track.js';

const $ = id => document.getElementById(id);
const sock = io({ transports: ['websocket', 'polling'] });
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

let L = null, seats = [], view = null, authed = false;

/* ---------------- เข้าด้วย PIN ---------------- */
const savedPin = sessionStorage.getItem('runningGame.pin') || '';
$('pin').value = savedPin;
$('pin').addEventListener('keydown', e => { if (e.key === 'Enter') auth(); });
$('pinBtn').addEventListener('click', auth);

function auth() {
  const pin = $('pin').value.trim();
  if (!pin) return;
  sock.emit('host:auth', { pin }, res => {
    if (!res?.ok) { $('pinErr').textContent = res?.msg || 'เข้าไม่ได้'; return; }
    sessionStorage.setItem('runningGame.pin', pin);
    authed = true;
    $('pinScreen').style.display = 'none';
    $('app').classList.add('show');
    $('urlBox').textContent = location.origin;
    startView();
    if (res.lobby) applyLobby(res.lobby);
  });
}

async function startView() {
  const cv = $('cv');
  view = await makeView(cv, { antialias: true, camera: 'broadcast', maxDpr: 2 });
  runLoop(view, cv);
}

/* ---------------- คำสั่งควบคุม ---------------- */
function cmd(ev, data) {
  sock.emit(ev, data, res => {
    $('ctrlMsg').textContent = res?.ok ? '' : (res?.msg || 'ทำรายการไม่สำเร็จ');
    $('ctrlMsg').className = res?.ok ? 'muted' : 'err';
  });
}

for (const b of document.querySelectorAll('#distBtns button[data-m]')) {
  b.onclick = () => cmd('host:distance', { meters: Number(b.dataset.m) });
}
for (const b of document.querySelectorAll('#botBtns button[data-b]')) {
  b.onclick = () => cmd('host:bots', { count: Number(b.dataset.b) });
}

$('mkHeats').onclick = () => cmd('host:heats', { size: Number($('heatSize').value) });
$('mkFinal').onclick = () => cmd('host:final', { n: Number($('finalN').value) });
$('startNext').onclick = () => cmd('host:start', {});
$('stopBtn').onclick = () => cmd('host:stop', {});
$('toLobby').onclick = () => cmd('host:lobby', {});
$('sweepBtn').onclick = () => cmd('host:sweep', {});
$('resetBtn').onclick = () => {
  if (confirm('ล้างคะแนนและสถิติของผู้เล่นทุกคน?')) cmd('host:reset', {});
};

$('camBroad').onclick = () => {
  view?.setCamMode('broadcast');
  $('camBroad').classList.add('on');
  $('camOver').classList.remove('on');
};
$('camOver').onclick = () => {
  view?.setCamMode('overview');
  $('camOver').classList.add('on');
  $('camBroad').classList.remove('on');
};

/* ---------------- สถานะล็อบบี้ ---------------- */
sock.on('hello', d => {
  if (!authed && savedPin) auth();
  else if (d.lobby) applyLobby(d.lobby);
});
sock.on('lobby', applyLobby);

const PHASE_TH = { lobby: 'รอเริ่มรอบ', countdown: 'นับถอยหลัง', playing: 'กำลังแข่ง', result: 'ประกาศผล' };

function applyLobby(lobby) {
  L = lobby;
  if (!authed) return;

  const humans = L.players.filter(p => !p.isBot);
  const onlineHumans = humans.filter(p => p.online);
  $('cntPill').textContent =
    onlineHumans.length + ' คน' + (L.botCount ? ` + บอท ${L.botCount}` : '');
  $('phasePill').textContent = PHASE_TH[L.phase] || L.phase;
  $('distPill').textContent = (L.trackMeters || 250) + ' ม.';
  view?.setTrackMeters?.(L.trackMeters || 250);

  for (const b of document.querySelectorAll('#distBtns button[data-m]')) {
    b.classList.toggle('on', Number(b.dataset.m) === L.trackMeters);
    b.disabled = L.phase === 'playing' || L.phase === 'countdown';
  }
  for (const b of document.querySelectorAll('#botBtns button[data-b]')) {
    b.classList.toggle('on', Number(b.dataset.b) === L.botCount);
    b.disabled = L.phase === 'playing' || L.phase === 'countdown';
  }

  const playing = L.phase === 'playing' || L.phase === 'countdown';
  $('startNext').disabled = playing || !L.heats.length;
  $('stopBtn').disabled = L.phase === 'lobby';
  $('mkHeats').disabled = playing;
  $('mkFinal').disabled = playing;
  $('resetBtn').disabled = playing;
  $('sweepBtn').disabled = playing;
  $('startNext').textContent =
    L.heatIndex + 1 < L.heats.length ? 'เริ่มสายที่ ' + (L.heatIndex + 2) : 'เริ่มสายที่ 1';

  const nameOf = t => L.players.find(p => p.token === t)?.name || '—';
  $('heats').innerHTML = L.heats.length
    ? L.heats
        .map(
          (h, i) =>
            '<div class="heat' + (i === L.heatIndex ? ' cur' : '') + '">' +
            '<div class="row"><b class="grow">สายที่ ' + (i + 1) + ' (' + h.length + ' ลู่)</b>' +
            '<button data-h="' + i + '" style="padding:4px 10px;font-size:13px">เริ่มสายนี้</button></div>' +
            '<div class="names">' + h.map(t => esc(nameOf(t))).join(' · ') + '</div></div>',
        )
        .join('')
    : '<p class="muted" style="font-size:13px;margin:0">ยังไม่ได้แบ่งสาย</p>';
  for (const b of $('heats').querySelectorAll('button[data-h]')) {
    b.onclick = () => cmd('host:start', { heat: Number(b.dataset.h) });
    b.disabled = playing;
  }

  $('plist').innerHTML = [...L.players]
    .sort((a, b) => b.total - a.total || (a.bestTime ?? 9999) - (b.bestTime ?? 9999))
    .map(
      p =>
        '<tr><td><span class="dot ' + (p.online ? 'on' : 'off') + '"></span></td>' +
        '<td>' + esc(p.name) + (p.isBot ? ' <span class="muted">[บอท]</span>' : '') + '</td>' +
        '<td class="num">' + (p.heat >= 0 ? p.heat + 1 : '—') + '</td>' +
        '<td class="num">' + (p.bestTime !== null ? p.bestTime.toFixed(2) + 's' : '—') + '</td>' +
        '<td class="num"><b>' + p.total + '</b></td>' +
        '<td><button data-k="' + p.token + '" class="ghost" style="padding:2px 8px;font-size:12px">ลบ</button></td></tr>',
    )
    .join('');
  for (const b of $('plist').querySelectorAll('button[data-k]')) {
    b.onclick = () => {
      if (confirm('ลบผู้เล่นคนนี้ออกจากการแข่ง?')) cmd('host:kick', { token: b.dataset.k });
    };
  }

  if (L.round?.seats?.length && !seats.length) {
    seats = L.round.seats;
    $('boardTitle').textContent = 'อันดับในรอบนี้';
  }

  $('heatPill').textContent = L.heatIndex >= 0 ? 'สายที่ ' + (L.heatIndex + 1) : 'ยังไม่เริ่ม';
  if (L.phase !== 'playing') {
    $('boardTitle').textContent = 'คะแนนรวมทั้งหมด';
    $('boardBody').innerHTML = [...L.players]
      .sort((a, b) => b.total - a.total)
      .slice(0, 12)
      .map(
        (p, i) =>
          '<tr><td>' + (i + 1) + '</td><td>' + esc(p.name) + '</td>' +
          '<td class="num"><b>' + p.total + '</b></td></tr>',
      )
      .join('');
    $('clock').textContent = '—';
  }
  if (L.phase === 'lobby') {
    overlay({ big: 'พร้อมวิ่ง!', text: 'ผู้เล่นเข้าที่ ' + location.origin });
  }
  if (L.phase === 'playing') overlay(null);
}

/* ---------------- ระหว่างแข่ง ---------------- */
sock.on('begin', d => {
  seats = d.seats || [];
  view?.setTrackMeters?.(d.trackMeters || 250);
  $('boardTitle').textContent = 'อันดับสดบนลู่วิ่ง';
  overlay(null);
});

sock.on('countdown', n => overlay(n > 0 ? { big: String(n), text: 'เข้าที่! ระวัง…' } : null));
sock.on('go', () => overlay(null));

sock.on('state', snap => {
  if (!view) return;
  const names = [];
  seats.forEach(s => { names[s.slot] = s.name; });
  view.apply(snap, { names });
  $('clock').textContent = (snap.t / 1000).toFixed(1) + 's';

  $('boardBody').innerHTML = [...snap.r]
    .sort((a, b) => a[7] - b[7])
    .map(r => {
      const nm = (names[r[0]] || 'ลู่ ' + (r[0] + 1)).slice(0, 14);
      const dist = (r[1] / 50).toFixed(1);
      const spd = (r[2] / 50).toFixed(1);
      const fin = r[5] & 1;
      const stum = r[5] & 2;
      return (
        '<tr>' +
        '<td>' + r[7] + '.</td>' +
        '<td><span class="swatch" style="background:' + TEAM_COLORS[r[0]] + '"></span> ' + esc(nm) + '</td>' +
        '<td class="num" style="color:' + (stum ? 'var(--bad)' : 'inherit') + '">' + spd + ' m/s</td>' +
        '<td class="num"><b>' + (fin ? (r[6] / 1000).toFixed(2) + 's' : dist + 'm') + '</b></td></tr>'
      );
    })
    .join('');
});

sock.on('result', res => {
  seats = [];
  overlay({
    big: 'จบสายที่ ' + (res.heatIndex + 1),
    text: res.reason + ' · ระยะทาง ' + res.trackMeters + ' เมตร',
    html:
      '<table><thead><tr><th>#</th><th>นักวิ่ง</th><th class="num">เวลา/ระยะ</th>' +
      '<th class="num">Streak</th><th class="num">แม่นยำ</th><th class="num">คะแนน</th></tr></thead><tbody>' +
      res.rank
        .map(
          r =>
            '<tr><td>' + r.rank + '</td>' +
            '<td><span class="swatch" style="background:' + TEAM_COLORS[r.slot] + '"></span> ' + esc(r.name) + '</td>' +
            '<td class="num">' + (r.finished ? r.finishTime.toFixed(2) + 's' : r.dist + ' ม.') + '</td>' +
            '<td class="num">x' + r.maxStreak + '</td>' +
            '<td class="num">' + r.accuracy + '%</td>' +
            '<td class="num"><b>' + r.score + '</b></td></tr>',
        )
        .join('') +
      '</tbody></table>',
  });
});

function overlay(o) {
  const el = $('overlay');
  if (!o) { el.style.display = 'none'; return; }
  el.style.display = '';
  $('ovBig').textContent = o.big || '';
  $('ovText').textContent = o.text || '';
  $('ovTable').innerHTML = o.html || '';
}
