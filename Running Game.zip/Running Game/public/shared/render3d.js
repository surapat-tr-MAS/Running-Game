/* ฉากสนามกรีฑา 3 มิติ (Three.js) — ไม่ใช้ shadow map เพื่อให้เครื่องทั่วไปและห้องเรียนลื่น 60fps */

import * as THREE from 'three';
import { TRACK, TEAM_COLORS } from './track.js';

const lam = (color, o = {}) => new THREE.MeshLambertMaterial({ color, ...o });

function makeFinishTexture() {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 512;
  const g = c.getContext('2d');
  const sq = 32;
  for (let y = 0; y < c.height; y += sq) {
    for (let x = 0; x < c.width; x += sq) {
      g.fillStyle = ((x / sq + y / sq) % 2 === 0) ? '#ffffff' : '#14181d';
      g.fillRect(x, y, sq, sq);
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function makeBannerTexture(text, bg = '#121a24', fg = '#ffffff') {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = bg;
  g.fillRect(0, 0, 256, 64);
  g.strokeStyle = '#ff6a00';
  g.lineWidth = 4;
  g.strokeRect(2, 2, 252, 60);
  g.fillStyle = fg;
  g.font = '800 28px Tahoma, sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(text, 128, 33);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function labelSprite() {
  const c = document.createElement('canvas');
  c.width = 280;
  c.height = 76;
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false }));
  sp.scale.set(4.8, 1.3, 1);
  sp.userData = { c, g: c.getContext('2d'), t, last: '' };
  return sp;
}

function drawLabel(sp, name, speed, streak, color, stumble, finished) {
  const spdText = speed.toFixed(1);
  const key = `${name}|${spdText}|${streak}|${stumble ? 1 : 0}|${finished ? 1 : 0}`;
  if (sp.userData.last === key) return;
  sp.userData.last = key;
  const { c, g, t } = sp.userData;
  g.clearRect(0, 0, c.width, c.height);

  g.fillStyle = stumble ? 'rgba(155, 22, 42, 0.88)' : 'rgba(10, 15, 22, 0.82)';
  g.beginPath();
  g.roundRect(6, 4, 268, 66, 12);
  g.fill();
  g.strokeStyle = stumble ? '#ff5470' : color;
  g.lineWidth = 3;
  g.stroke();

  g.fillStyle = '#ffffff';
  g.font = '700 22px Tahoma, sans-serif';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(name.slice(0, 14), 140, 25);

  const sub = stumble
    ? 'พลาด! รีเซ็ตจังหวะ'
    : finished
      ? 'เข้าเส้นชัย!'
      : `${spdText} m/s` + (streak >= 2 ? `  ·  x${streak}` : '');
  g.fillStyle = stumble ? '#ffd0d8' : streak >= 8 ? '#ffd400' : '#9ee8d8';
  g.font = '700 18px Tahoma, sans-serif';
  g.fillText(sub, 140, 52);

  t.needsUpdate = true;
}

/* สร้างตัวละครนักวิ่ง 3 มิติพร้อมจุดหมุนแขน/ขา */
function buildRunner(color) {
  const grp = new THREE.Group();

  const body = new THREE.Group();
  grp.add(body);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.82, 0.72), lam(color));
  torso.position.y = 1.28;
  body.add(torso);

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.48), lam(0xf4d2b5));
  head.position.set(0.05, 1.98, 0);
  body.add(head);

  const headband = new THREE.Mesh(new THREE.BoxGeometry(0.51, 0.12, 0.51), lam(color));
  headband.position.set(0.05, 2.08, 0);
  body.add(headband);

  const limbMat = lam(0x1f2833);
  const shoeMat = lam(0xffffff);

  const makeLeg = z => {
    const piv = new THREE.Group();
    piv.position.set(0, 0.88, z);
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.76, 0.24), limbMat);
    leg.position.y = -0.38;
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.14, 0.26), shoeMat);
    shoe.position.set(0.06, -0.78, 0);
    piv.add(leg, shoe);
    body.add(piv);
    return piv;
  };

  const makeArm = z => {
    const piv = new THREE.Group();
    piv.position.set(0, 1.62, z);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.66, 0.2), lam(0xf4d2b5));
    arm.position.y = -0.3;
    piv.add(arm);
    body.add(piv);
    return piv;
  };

  const legL = makeLeg(-0.19);
  const legR = makeLeg(0.19);
  const armL = makeArm(-0.48);
  const armR = makeArm(0.48);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.75, 18),
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.03;

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.85, 1.18, 24),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.04;
  ring.visible = false;

  const label = labelSprite();
  label.position.y = 3.1;

  grp.add(shadow, ring, label);
  grp.userData = { body, torso, legL, legR, armL, armR, ring, label, color };
  return grp;
}

export function createView(canvas, opts = {}) {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: !!opts.antialias,
    powerPreference: 'high-performance',
  });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, opts.maxDpr ?? 1.5));
  renderer.setClearColor(0x0c1622);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x0c1622, 85, 280);

  const camera = new THREE.PerspectiveCamera(48, 16 / 9, 0.5, 450);

  scene.add(new THREE.HemisphereLight(0xeef6ff, 0x264132, 1.1));
  const sun = new THREE.DirectionalLight(0xfff5e4, 0.85);
  sun.position.set(60, 80, 50);
  scene.add(sun);

  let trackMeters = opts.trackMeters || TRACK.defaultMeters;
  const maxLen = TRACK.maxMeters + 40;
  const totalW = TRACK.lanes * TRACK.laneWidth;
  const halfW = totalW / 2;
  const laneZ = slot => -halfW + (slot + 0.5) * TRACK.laneWidth;

  /* --- พื้นหญ้าและลู่วิ่ง --- */
  const grass = new THREE.Mesh(new THREE.PlaneGeometry(maxLen + 80, 90), lam(0x285c3b));
  grass.rotation.x = -Math.PI / 2;
  grass.position.set(maxLen / 2 - 15, -0.02, 0);
  scene.add(grass);

  const trackMesh = new THREE.Mesh(new THREE.PlaneGeometry(maxLen, totalW), lam(0xa33f35));
  trackMesh.rotation.x = -Math.PI / 2;
  trackMesh.position.set(maxLen / 2 - 10, 0, 0);
  scene.add(trackMesh);

  // เส้นแบ่งลู่สีขาว
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xf4f7f5 });
  for (let i = 0; i <= TRACK.lanes; i++) {
    const z = -halfW + i * TRACK.laneWidth;
    const line = new THREE.Mesh(new THREE.PlaneGeometry(maxLen, 0.1), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(maxLen / 2 - 10, 0.015, z);
    scene.add(line);
  }

  // เส้นสตาร์ท 0m
  const startLine = new THREE.Mesh(new THREE.PlaneGeometry(0.35, totalW), lineMat);
  startLine.rotation.x = -Math.PI / 2;
  startLine.position.set(0, 0.02, 0);
  scene.add(startLine);

  // ป้ายบอกระยะทางและเสาไฟข้างสนามทุก 50 เมตร
  const poleMat = lam(0x4a5565);
  const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffe8a3 });
  for (let m = 50; m <= TRACK.maxMeters; m += 50) {
    const mark = new THREE.Mesh(new THREE.PlaneGeometry(0.22, totalW), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.45 }));
    mark.rotation.x = -Math.PI / 2;
    mark.position.set(m, 0.018, 0);
    scene.add(mark);

    for (const s of [-1, 1]) {
      const z = s * (halfW + 1.8);
      const pole = new THREE.Mesh(new THREE.BoxGeometry(0.3, 6.5, 0.3), poleMat);
      pole.position.set(m, 3.25, z);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.35, 0.6), bulbMat);
      lamp.position.set(m, 6.5, z - s * 0.3);
      scene.add(pole, lamp);
    }

    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(3.4, 1.0),
      new THREE.MeshBasicMaterial({ map: makeBannerTexture(`${m} ม.`), side: THREE.DoubleSide }),
    );
    sign.position.set(m, 2.3, -halfW - 1.8);
    scene.add(sign);
  }

  // อัฒจันทร์คนดู 2 ฝั่ง
  const standMat = lam(0x283444);
  for (const s of [-1, 1]) {
    for (let step = 0; step < 3; step++) {
      const tier = new THREE.Mesh(new THREE.BoxGeometry(maxLen, 0.8 + step * 0.8, 2.2), standMat);
      tier.position.set(maxLen / 2 - 10, (0.8 + step * 0.8) / 2, s * (halfW + 5 + step * 2.4));
      scene.add(tier);
    }
  }

  /* --- ซุ้มเส้นชัย (ขยับตามระยะทางของรอบได้) --- */
  const finishGroup = new THREE.Group();
  const finishStrip = new THREE.Mesh(
    new THREE.PlaneGeometry(1.4, totalW),
    new THREE.MeshBasicMaterial({ map: makeFinishTexture() }),
  );
  finishStrip.rotation.x = -Math.PI / 2;
  finishStrip.position.y = 0.025;
  finishGroup.add(finishStrip);

  const postMat = lam(0xff6a00);
  for (const s of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.5, 5.2, 0.5), postMat);
    post.position.set(0, 2.6, s * (halfW + 0.6));
    finishGroup.add(post);
  }
  const banner = new THREE.Mesh(
    new THREE.BoxGeometry(0.4, 1.4, totalW + 1.6),
    new THREE.MeshBasicMaterial({ map: makeBannerTexture('FINISH  เส้นชัย', '#0d1520', '#ffd400') }),
  );
  banner.position.set(0, 4.9, 0);
  finishGroup.add(banner);
  finishGroup.position.x = trackMeters;
  scene.add(finishGroup);

  /* --- นักวิ่ง 8 ลู่ --- */
  const runners = TEAM_COLORS.map((c, slot) => {
    const grp = buildRunner(c);
    grp.position.set(0, 0, laneZ(slot));
    grp.visible = false;
    scene.add(grp);
    return {
      grp,
      dist: 0,
      targetDist: 0,
      speed: 0,
      phase: 0,
      init: false,
      finished: false,
      stumble: false,
    };
  });

  let camMode = opts.camera || 'broadcast';
  let follow = -1;
  let names = [];
  let camPos = new THREE.Vector3(-12, 10, 18);
  let camLook = new THREE.Vector3(10, 1, 0);

  function setTrackMeters(m) {
    trackMeters = m;
    finishGroup.position.x = m;
  }

  function apply(snap, meta) {
    if (snap.m && snap.m !== trackMeters) setTrackMeters(snap.m);
    if (meta?.names) names = meta.names;

    const seen = new Set();
    for (const row of snap.r) {
      const [slot, qDist, qSpeed, streak, , flags] = row;
      const R = runners[slot];
      if (!R) continue;
      seen.add(slot);
      const dist = qDist / 50;
      const spd = qSpeed / 50;
      if (!R.init) {
        R.dist = dist;
        R.init = true;
      }
      R.targetDist = dist;
      R.speed = spd;
      R.finished = !!(flags & 1);
      R.stumble = !!(flags & 2);
      const turbo = !!(flags & 4);

      R.grp.visible = true;
      R.grp.userData.ring.visible = turbo || slot === follow;
      drawLabel(
        R.grp.userData.label,
        names[slot] || 'ลู่ ' + (slot + 1),
        spd,
        streak,
        TEAM_COLORS[slot],
        R.stumble,
        R.finished,
      );
    }

    runners.forEach((R, i) => {
      if (!seen.has(i)) {
        R.grp.visible = false;
        R.init = false;
      }
    });
  }

  function updateCamera(dt) {
    let wantPos, wantLook;
    const dockEl = document.getElementById('rhythmDock');
    const hasDock = dockEl && dockEl.classList.contains('show');
    const lookDrop = hasDock ? -1.2 : 0; // ยกภาพนักวิ่งขึ้นเหนือรางจังหวะด้านล่าง

    if (camMode === 'overview') {
      const midX = trackMeters * 0.5;
      wantPos = new THREE.Vector3(midX - 20, Math.max(38, trackMeters * 0.25), Math.max(46, trackMeters * 0.34));
      wantLook = new THREE.Vector3(midX, lookDrop, 0);
    } else if (camMode === 'follow' && follow >= 0 && runners[follow]?.grp.visible) {
      const R = runners[follow];
      const z = laneZ(follow);
      wantPos = new THREE.Vector3(R.dist - 9.5, 5.6, z + 11.5);
      wantLook = new THREE.Vector3(R.dist + 8.5, 1.3 + lookDrop, z * 0.5);
    } else {
      // มุมกล้องถ่ายทอดสด: ตามกลุ่มผู้นำของสนาม
      let leadX = 0;
      for (const R of runners) {
        if (R.grp.visible && R.dist > leadX) leadX = R.dist;
      }
      wantPos = new THREE.Vector3(leadX - 13, 10.5, 19.5);
      wantLook = new THREE.Vector3(leadX + 7, 1.2 + lookDrop, 0);
    }

    const alpha = 1 - Math.exp(-dt * 5.0);
    camPos.lerp(wantPos, alpha);
    camLook.lerp(wantLook, alpha);
    camera.position.copy(camPos);
    camera.lookAt(camLook);
  }

  let last = performance.now();
  function render() {
    const now = performance.now();
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;

    const k = 1 - Math.exp(-dt * 14);
    for (const R of runners) {
      if (!R.grp.visible) continue;
      R.dist += (R.targetDist - R.dist) * k;
      R.grp.position.x = R.dist;

      const u = R.grp.userData;
      if (R.finished) {
        u.legL.rotation.z *= 0.85;
        u.legR.rotation.z *= 0.85;
        u.armL.rotation.z *= 0.85;
        u.armR.rotation.z *= 0.85;
        u.body.rotation.z *= 0.85;
        u.body.position.y *= 0.85;
      } else {
        R.phase += dt * (R.speed * 1.45);
        const swing = Math.sin(R.phase) * Math.min(0.95, 0.35 + R.speed * 0.04);
        u.legL.rotation.z = swing;
        u.legR.rotation.z = -swing;
        u.armL.rotation.z = -swing * 0.85;
        u.armR.rotation.z = swing * 0.85;
        u.body.position.y = Math.abs(Math.sin(R.phase)) * 0.14;
        // เอียงตัวไปข้างหน้าตามความเร็ว หรือโยกเมื่อสะดุด
        if (R.stumble) {
          u.body.rotation.z = -0.32;
          u.body.rotation.x = Math.sin(now * 0.03) * 0.25;
        } else {
          u.body.rotation.z = -Math.min(0.24, R.speed * 0.012);
          u.body.rotation.x = 0;
        }
      }
    }

    updateCamera(dt);
    renderer.render(scene, camera);
  }

  function resize(w, h) {
    camera.aspect = Math.max(0.4, w / h);
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }

  return {
    kind: '3d',
    apply,
    render,
    resize,
    setTrackMeters,
    setFollow: s => { follow = s; },
    setCamMode: m => { camMode = m; },
    dispose: () => { renderer.dispose(); },
  };
}
