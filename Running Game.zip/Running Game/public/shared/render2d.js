/* ตัวแสดงผลสำรองแบบ 2 มิติ มองจากด้านบน (กินทรัพยากรน้อยมาก) */

import { TRACK, TEAM_COLORS } from './track.js';

export function createView(canvas, opts = {}) {
  const g = canvas.getContext('2d');
  let W = canvas.width, H = canvas.height, dpr = Math.min(devicePixelRatio || 1, 2);
  let trackMeters = opts.trackMeters || TRACK.defaultMeters;
  let names = [], follow = -1, snap = null;

  const runners = TEAM_COLORS.map(() => ({
    dist: 0, targetDist: 0, speed: 0, phase: 0, init: false,
  }));

  function resize(w, h) {
    dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    W = canvas.width;
    H = canvas.height;
  }
  resize(canvas.clientWidth || 960, canvas.clientHeight || 540);

  function apply(s, meta) {
    snap = s;
    if (s.m) trackMeters = s.m;
    if (meta?.names) names = meta.names;
    for (const row of s.r) {
      const [slot, qDist, qSpeed] = row;
      const R = runners[slot];
      if (!R) continue;
      const dist = qDist / 50;
      const spd = qSpeed / 50;
      if (!R.init) {
        R.dist = dist;
        R.init = true;
      }
      R.targetDist = dist;
      R.speed = spd;
    }
  }

  let last = performance.now();

  function render() {
    const now = performance.now();
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const k = 1 - Math.exp(-dt * 14);

    for (const R of runners) {
      if (!R.init) continue;
      R.dist += (R.targetDist - R.dist) * k;
      R.phase += dt * (R.speed * 1.6);
    }

    const dockEl = document.getElementById('rhythmDock');
    const dockH = dockEl && dockEl.classList.contains('show') ? dockEl.offsetHeight * dpr : 0;

    g.fillStyle = '#183324';
    g.fillRect(0, 0, W, H);

    const padX = 56 * dpr;
    const topY = 66 * dpr;
    const botY = Math.max(topY + 140 * dpr, H - dockH - 22 * dpr);
    const trackW = Math.max(120, W - padX * 2);
    const trackH = botY - topY;
    const laneH = trackH / TRACK.lanes;

    const xOf = m => padX + (m / trackMeters) * trackW;

    // พื้นลู่วิ่งสีอิฐ
    g.fillStyle = '#9e3e34';
    g.fillRect(padX, topY, trackW, trackH);

    // ไฮไลท์ลู่ของตัวเอง
    if (follow >= 0 && follow < TRACK.lanes) {
      g.fillStyle = 'rgba(255,255,255,0.08)';
      g.fillRect(padX, topY + follow * laneH, trackW, laneH);
    }

    // เส้นแบ่งลู่
    g.strokeStyle = 'rgba(255,255,255,0.65)';
    g.lineWidth = Math.max(1, 1.5 * dpr);
    for (let i = 0; i <= TRACK.lanes; i++) {
      const y = topY + i * laneH;
      g.beginPath();
      g.moveTo(padX, y);
      g.lineTo(padX + trackW, y);
      g.stroke();
    }

    // เส้นบอกระยะทุก 50 เมตร
    g.fillStyle = 'rgba(255,255,255,0.75)';
    g.font = `700 ${Math.round(11 * dpr)}px Tahoma, sans-serif`;
    g.textAlign = 'center';
    for (let m = 0; m <= trackMeters; m += 50) {
      const mx = xOf(m);
      g.strokeStyle = 'rgba(255,255,255,0.25)';
      g.beginPath();
      g.moveTo(mx, topY);
      g.lineTo(mx, botY);
      g.stroke();
      g.fillText(m + 'm', mx, topY - 8 * dpr);
    }

    // เส้นชัยลายตารางหมากรุก
    const fx = xOf(trackMeters);
    const sq = Math.max(6 * dpr, laneH * 0.35);
    const rows = Math.ceil(trackH / sq);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < 2; c++) {
        g.fillStyle = (r + c) % 2 === 0 ? '#ffffff' : '#14181d';
        g.fillRect(fx - sq + c * sq, topY + r * sq, sq, Math.min(sq, botY - (topY + r * sq)));
      }
    }

    if (!snap) return;

    // วาดนักวิ่งทีละคน
    for (const row of snap.r) {
      const [slot, , , streak, level, flags] = row;
      const R = runners[slot];
      if (!R || !R.init) continue;
      const rx = xOf(R.dist);
      const ry = topY + (slot + 0.5) * laneH;
      const rad = Math.min(laneH * 0.34, 14 * dpr);
      const stumbling = !!(flags & 2);
      const turbo = !!(flags & 4);
      const finished = !!(flags & 1);
      const bob = finished ? 0 : Math.sin(R.phase) * 2.5 * dpr;

      // เส้นสปีดเมื่อวิ่งคอมโบสูง
      if (turbo && !finished) {
        g.strokeStyle = TEAM_COLORS[slot] + 'aa';
        g.lineWidth = 2.5 * dpr;
        for (let t = -1; t <= 1; t++) {
          g.beginPath();
          g.moveTo(rx - rad * 1.1, ry + t * rad * 0.5);
          g.lineTo(rx - rad * 3.2, ry + t * rad * 0.5);
          g.stroke();
        }
      }

      // วงไฮไลท์ผู้เล่นที่ติดตาม
      if (slot === follow) {
        g.strokeStyle = '#ffffff';
        g.lineWidth = 2 * dpr;
        g.beginPath();
        g.arc(rx, ry, rad * 1.45, 0, Math.PI * 2);
        g.stroke();
      }

      // เงาและตัวนักวิ่ง
      g.fillStyle = stumbling ? '#ff5470' : TEAM_COLORS[slot];
      g.beginPath();
      g.arc(rx, ry + bob, rad, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = '#0b1016';
      g.lineWidth = 1.8 * dpr;
      g.stroke();

      // หมายเลขลู่บนตัว
      g.fillStyle = '#0b1016';
      g.font = `800 ${Math.round(rad * 1.1)}px Tahoma, sans-serif`;
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.fillText(String(slot + 1), rx, ry + bob);

      // ป้ายชื่อ + ความเร็ว + สถานะสะดุด
      const nm = (names[slot] || 'ลู่ ' + (slot + 1)).slice(0, 12);
      const tag = stumbling
        ? nm + ' พลาด!'
        : `${nm} (${R.speed.toFixed(1)} m/s${streak >= 2 ? ' x' + streak : ''})`;
      g.font = `700 ${Math.round(11 * dpr)}px Tahoma, sans-serif`;
      const tw = g.measureText(tag).width + 10 * dpr;
      const tx = Math.min(W - tw - 4 * dpr, Math.max(4 * dpr, rx + rad + 6 * dpr));

      g.fillStyle = stumbling ? 'rgba(180,30,50,0.88)' : 'rgba(11,16,22,0.78)';
      g.fillRect(tx, ry - 9 * dpr, tw, 18 * dpr);
      g.fillStyle = level >= 8 ? '#ffd400' : '#ffffff';
      g.textAlign = 'left';
      g.fillText(tag, tx + 5 * dpr, ry);
    }
  }

  return {
    kind: '2d',
    apply,
    render,
    resize,
    setTrackMeters: m => { trackMeters = m; },
    setFollow: s => { follow = s; },
    setCamMode: () => {},
    dispose: () => {},
  };
}
