/* ตัวแสดงผลรางจังหวะ WASD (60fps) + ระบบสังเคราะห์เสียงจังหวะผ่าน Web Audio API */

import { KEYS, KEY_META, RULES, hitWindows } from './track.js';

export function createRhythmUI(canvas) {
  const g = canvas.getContext('2d');
  let W = 600, H = 108, dpr = Math.min(devicePixelRatio || 1, 2);

  /* สถานะจังหวะที่ได้รับจากเซิร์ฟเวอร์ */
  let state = {
    streak: 0,
    level: 0,
    beatMs: RULES.maxBeatMs,
    speed: RULES.startSpeed,
    notes: [],
  };
  let getElapsedMs = () => 0;
  let lastJudgeSeq = 0;

  /* เอฟเฟกต์ฝั่งภาพ */
  let popup = null;        // { text, color, bornMs, sub }
  let ringFlash = null;    // { color, bornMs }
  let keyFlash = { W: 0, A: 0, S: 0, D: 0 };
  let resetShakeUntil = 0;

  /* ระบบเสียง Web Audio API (ไม่ต้องโหลดไฟล์ mp3 ภายนอก) */
  let audioCtx = null;
  let muted = false;
  function ensureAudio() {
    if (muted) return null;
    if (!audioCtx && (window.AudioContext || window.webkitAudioContext)) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      audioCtx = new Ctx();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  }

  function tone(freq, dur, type = 'sine', gainVal = 0.14, freqEnd = null) {
    const ctx = ensureAudio();
    if (!ctx) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (freqEnd) osc.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    gain.gain.setValueAtTime(gainVal, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur);
  }

  function playCue(kind, level = 0) {
    if (muted) return;
    if (kind === 'perfect') {
      const pitch = 520 + Math.min(14, level) * 32;
      tone(pitch, 0.09, 'triangle', 0.16, pitch * 1.25);
    } else if (kind === 'good') {
      const pitch = 420 + Math.min(14, level) * 20;
      tone(pitch, 0.08, 'sine', 0.12);
    } else if (kind === 'miss') {
      tone(190, 0.22, 'sawtooth', 0.14, 95);
    } else if (kind === 'countdown') {
      tone(440, 0.1, 'sine', 0.12);
    } else if (kind === 'go') {
      tone(880, 0.24, 'triangle', 0.18, 1046);
    } else if (kind === 'finish') {
      tone(523, 0.12, 'triangle', 0.15);
      setTimeout(() => tone(659, 0.12, 'triangle', 0.15), 90);
      setTimeout(() => tone(784, 0.26, 'triangle', 0.16), 180);
    }
  }

  function resize() {
    const r = canvas.getBoundingClientRect();
    dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.round(r.width * dpr));
    canvas.height = Math.max(1, Math.round(r.height * dpr));
    W = canvas.width;
    H = canvas.height;
  }

  function setElapsedProvider(fn) {
    getElapsedMs = fn;
  }

  function flashKey(k) {
    ensureAudio();
    if (k in keyFlash) keyFlash[k] = performance.now();
  }

  function applyRhythm(data) {
    if (!data) return;
    state = data;
    const j = data.judge;
    if (j && j.seq !== lastJudgeSeq) {
      lastJudgeSeq = j.seq;
      const now = performance.now();
      if (j.kind === 'perfect') {
        popup = { text: 'PERFECT!', sub: 'เร็วขึ้น!', color: '#39d98a', bornMs: now };
        ringFlash = { color: '#39d98a', bornMs: now };
        playCue('perfect', data.level);
      } else if (j.kind === 'good') {
        popup = { text: 'GOOD!', sub: '+' + (data.streak || 1), color: '#ffd400', bornMs: now };
        ringFlash = { color: '#ffd400', bornMs: now };
        playCue('good', data.level);
      } else if (j.kind === 'miss') {
        const msg =
          j.reason === 'wrong' ? 'ผิดปุ่ม! รีเซ็ตช้าสุด'
            : j.reason === 'timeout' ? 'หลุดจังหวะ! รีเซ็ตช้าสุด'
            : 'ไม่ตรงจังหวะ! รีเซ็ตช้าสุด';
        popup = { text: 'MISS!', sub: msg, color: '#ff5470', bornMs: now };
        ringFlash = { color: '#ff5470', bornMs: now };
        resetShakeUntil = now + 320;
        playCue('miss');
      }
    }
  }

  function draw() {
    const nowPerf = performance.now();
    const elapsedMs = getElapsedMs();

    const shake = nowPerf < resetShakeUntil ? Math.sin(nowPerf * 0.08) * 4 * dpr : 0;

    g.clearRect(0, 0, W, H);
    g.save();
    g.translate(shake, 0);

    // พื้นหลังรางจังหวะ + เส้นความเร็วเคลื่อนที่ตามความเร็ววิ่งจริง
    const bgGrad = g.createLinearGradient(0, 0, W, 0);
    bgGrad.addColorStop(0, '#101822');
    bgGrad.addColorStop(1, '#0b1017');
    g.fillStyle = bgGrad;
    g.fillRect(0, 0, W, H);

    const hitX = Math.round(Math.min(130 * dpr, W * 0.20));
    const cy = Math.round(H * 0.52);

    // เส้นวิ่งแนวตั้ง (Visual Speed Lines) ช่วยให้รู้สึกถึงความเร็วจริง
    const stripeGap = 80 * dpr;
    const speedPx = (state.speed || 4) * 14 * dpr;
    const phaseShift = ((nowPerf / 1000) * speedPx) % stripeGap;
    g.strokeStyle = 'rgba(255,255,255,0.04)';
    g.lineWidth = 2 * dpr;
    for (let sx = W - phaseShift; sx > hitX; sx -= stripeGap) {
      g.beginPath();
      g.moveTo(sx, 8 * dpr);
      g.lineTo(sx - 18 * dpr, H - 8 * dpr);
      g.stroke();
    }

    // เส้นแกนกลางราง
    g.strokeStyle = 'rgba(255,255,255,0.10)';
    g.lineWidth = 2 * dpr;
    g.beginPath();
    g.moveTo(hitX, cy);
    g.lineTo(W - 14 * dpr, cy);
    g.stroke();

    // กรอบหน้าต่างการกด (Good Window Zone)
    const trackLen = W - hitX - 28 * dpr;
    const pxPerMs = trackLen / RULES.previewMs;
    const { perfect, good } = hitWindows(state.beatMs || RULES.maxBeatMs);

    const goodPx = good * pxPerMs;
    g.fillStyle = 'rgba(255, 212, 0, 0.08)';
    g.fillRect(hitX - goodPx, 10 * dpr, goodPx * 2, H - 20 * dpr);

    const perfPx = perfect * pxPerMs;
    g.fillStyle = 'rgba(57, 217, 138, 0.14)';
    g.fillRect(hitX - perfPx, 10 * dpr, perfPx * 2, H - 20 * dpr);

    // เส้นจังหวะแนวตั้งตรงจุด Hit
    g.strokeStyle = 'rgba(255,255,255,0.35)';
    g.lineWidth = 2 * dpr;
    g.beginPath();
    g.moveTo(hitX, 6 * dpr);
    g.lineTo(hitX, H - 6 * dpr);
    g.stroke();

    // วงกลม Hit Target + Pulse ตามจังหวะโน้ตถัดไป
    const baseR = 29 * dpr;
    let pulseScale = 1;
    const head = state.notes?.[0];
    if (head) {
      const rem = head[2] - elapsedMs;
      const beatMs = state.beatMs || RULES.maxBeatMs;
      if (rem >= 0 && rem <= beatMs) {
        pulseScale = 1 + 0.18 * (1 - rem / beatMs);
      }
    }

    g.strokeStyle = '#8ea0b4';
    g.lineWidth = 3 * dpr;
    g.beginPath();
    g.arc(hitX, cy, baseR * pulseScale, 0, Math.PI * 2);
    g.stroke();

    // แฟลชวงเป้าหมายเมื่อกดโดน/พลาด
    if (ringFlash) {
      const age = nowPerf - ringFlash.bornMs;
      if (age < 260) {
        const p = age / 260;
        g.save();
        g.globalAlpha = 1 - p;
        g.strokeStyle = ringFlash.color;
        g.lineWidth = (5 - p * 3) * dpr;
        g.beginPath();
        g.arc(hitX, cy, baseR * (1 + p * 0.6), 0, Math.PI * 2);
        g.stroke();
        g.restore();
      } else {
        ringFlash = null;
      }
    }

    // วาดโน้ตที่กำลังเลื่อนเข้ามาจากขวาไปซ้าย
    const notes = state.notes || [];
    for (let i = notes.length - 1; i >= 0; i--) {
      const [, keyIdx, targetMs] = notes[i];
      const key = KEYS[keyIdx] || 'W';
      const meta = KEY_META[key];
      const remMs = targetMs - elapsedMs;
      if (remMs > RULES.previewMs + 150 || remMs < -320) continue;

      const nx = hitX + remMs * pxPerMs;
      const r = (i === 0 ? 27 : 23) * dpr;
      const inZone = Math.abs(remMs) <= good;

      g.save();
      if (remMs < -good) g.globalAlpha = Math.max(0.15, 1 + (remMs + good) / 200);

      // เงาเรืองแสงเมื่อเข้าสู่ระยะกดได้
      if (i === 0 && inZone) {
        g.fillStyle = meta.color + '44';
        g.beginPath();
        g.arc(nx, cy, r + 7 * dpr, 0, Math.PI * 2);
        g.fill();
      }

      // ตัวเหรียญปุ่ม
      g.fillStyle = i === 0 ? meta.dark : '#1a232e';
      g.strokeStyle = meta.color;
      g.lineWidth = (i === 0 ? 3.5 : 2.2) * dpr;
      g.beginPath();
      g.arc(nx, cy, r, 0, Math.PI * 2);
      g.fill();
      g.stroke();

      // ตัวอักษร W / A / S / D และลูกศรเล็กด้านล่าง
      g.fillStyle = '#ffffff';
      g.font = `800 ${Math.round((i === 0 ? 21 : 17) * dpr)}px "Cascadia Mono", Consolas, Tahoma, sans-serif`;
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.fillText(meta.label, nx, cy - 3 * dpr);

      g.fillStyle = meta.color;
      g.font = `700 ${Math.round(10 * dpr)}px Tahoma, sans-serif`;
      g.fillText(meta.arrow, nx, cy + 14 * dpr);

      g.restore();
    }

    // ข้อความบอกผลจังหวะ (PERFECT! / GOOD! / MISS!)
    if (popup) {
      const age = nowPerf - popup.bornMs;
      if (age < 750) {
        const p = age / 750;
        const py = 24 * dpr - p * 12 * dpr;
        g.save();
        g.globalAlpha = Math.max(0, 1 - p * p);
        g.fillStyle = popup.color;
        g.font = `800 ${Math.round(18 * dpr)}px Tahoma, sans-serif`;
        g.textAlign = 'left';
        g.textBaseline = 'middle';
        g.fillText(popup.text, hitX + 46 * dpr, py);

        if (popup.sub) {
          g.fillStyle = '#e8eef5';
          g.font = `600 ${Math.round(13 * dpr)}px Tahoma, sans-serif`;
          g.fillText(popup.sub, hitX + 46 * dpr, py + 18 * dpr);
        }
        g.restore();
      } else {
        popup = null;
      }
    }

    // ตัวบอกปุ่มที่กดติดล่าสุดตรงมุมซ้าย
    g.fillStyle = '#8ea0b4';
    g.font = `600 ${Math.round(11 * dpr)}px Tahoma, sans-serif`;
    g.textAlign = 'center';
    g.fillText('กดตรงวงนี้', hitX, H - 10 * dpr);

    g.restore();
  }

  return {
    resize,
    draw,
    applyRhythm,
    setElapsedProvider,
    flashKey,
    playCue,
    setMuted: m => { muted = !!m; },
    isMuted: () => muted,
  };
}
