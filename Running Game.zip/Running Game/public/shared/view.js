/* เลือกตัวแสดงผลให้เหมาะกับเครื่อง (3 มิติ WebGL หรือ 2 มิติ Canvas สำรอง)
   ต่อท้าย URL ด้วย ?2d=1 เพื่อเปิดโหมดประหยัดสำหรับเครื่องเก่า */

const KEY = 'runningGame.renderer';

export function preferred() {
  const q = new URLSearchParams(location.search);
  if (q.get('2d') === '1') return '2d';
  if (q.get('3d') === '1') return '3d';
  return localStorage.getItem(KEY) || 'auto';
}

function webglOK() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}

export async function makeView(canvas, opts = {}) {
  const want = opts.force || preferred();
  if (want !== '2d' && webglOK()) {
    try {
      const m = await import('./render3d.js');
      return m.createView(canvas, opts);
    } catch (e) {
      console.warn('สร้างฉาก 3 มิติไม่สำเร็จ ใช้โหมด 2 มิติแทน:', e);
    }
  }
  const m = await import('./render2d.js');
  return m.createView(canvas, opts);
}

export function runLoop(view, canvas, onFrame) {
  const fit = () => {
    const r = canvas.getBoundingClientRect();
    view.resize(Math.max(1, r.width), Math.max(1, r.height));
  };
  fit();
  addEventListener('resize', fit);
  let stop = false;
  const frame = () => {
    if (stop) return;
    view.render();
    if (onFrame) onFrame();
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
  return () => {
    stop = true;
    removeEventListener('resize', fit);
  };
}
