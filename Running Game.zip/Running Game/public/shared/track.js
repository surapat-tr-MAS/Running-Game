/* ค่ากติกา สนามวิ่ง และเส้นโค้งจังหวะ (ใช้ร่วมกันทั้งเซิร์ฟเวอร์และไคลเอนต์)
   ต้องไม่มี dependency ภายนอก เพื่อให้ import ได้ทั้งฝั่ง Node และ Browser */

export const KEYS = ['W', 'A', 'S', 'D'];

export const KEY_META = {
  W: { label: 'W', arrow: '▲', color: '#19d3d9', dark: '#0b4f54' },
  A: { label: 'A', arrow: '◀', color: '#ffd400', dark: '#5c4a00' },
  S: { label: 'S', arrow: '▼', color: '#ff4d6d', dark: '#5e1121' },
  D: { label: 'D', arrow: '▶', color: '#39d98a', dark: '#0c4f2f' },
};

export const TRACK = {
  lanes: 8,
  laneWidth: 2.2,       // ความกว้างต่อลู่ (เมตร)
  defaultMeters: 250,   // ระยะทางมาตรฐาน (เมตร)
  minMeters: 100,
  maxMeters: 500,
};

export const RULES = {
  tickHz: 20,
  countdownSec: 5,
  roundMaxSec: 90,      // เวลาสูงสุดต่อรอบ กันกรณีมีผู้เล่นค้างไม่เข้าเส้นชัย
  startSpeed: 4.0,      // ความเร็วเริ่มต้น (m/s)
  minSpeed: 1.4,        // ความเร็วต่ำสุดเมื่อพลาดติด ๆ กัน (m/s)
  maxSpeed: 19.0,       // ความเร็วสูงสุด (m/s)
  cruiseFloor: 2.2,     // แรงเฉื่อยจะค่อย ๆ ลดลงสู่ระดับนี้หากไม่ได้กดตรงจังหวะเลย
  dragPerSec: 0.45,     // แรงต้านชะลอความเร็วเบา ๆ ต่อวินาทีเมื่อไม่ได้เร่ง
  missSpeedKeep: 0.44,  // พลาด 1 ครั้ง ความเร็วลดเหลือ 44% ของเดิม

  /* จังหวะ (มิลลิวินาที) — ยิ่งกดถูกต่อเนื่อง ระยะห่างปุ่มยิ่งสั้นลง (ไวขึ้น) */
  maxBeatMs: 1100,      // ระดับ 0 (ช้าสุดหลังเริ่มหรือหลังพลาด)
  minBeatMs: 340,       // ระดับสูงสุด (ไวสุด)
  maxLevel: 14,         // จำนวนขั้นความไว 0..14 (แสดงผลเป็น Lv.1..Lv.15)
  leadInMs: 1200,       // หน่วงเวลาก่อนปุ่มแรกเข้าจุดกดหลังเริ่มรอบ
  previewMs: 2200,      // ระยะเวลาที่เห็นปุ่มล่วงหน้าบนรางจังหวะ
  missLockoutMs: 200,   // กันกดเบิ้ลโดยไม่ตั้งใจหลังพลาดทันที
  latencyGraceMs: 170,  // เผื่อความหน่วงเครือข่ายก่อนตัดสินว่าปล่อยปุ่มหลุดจอ

  /* คะแนนโบนัสเข้าเส้นชัยตามอันดับ (บวกเพิ่มจากคะแนนจังหวะ) */
  placeBonus: [100, 75, 55, 40, 30, 20, 15, 10],
};

/** ระยะห่างระหว่างปุ่ม (ms) ตามระดับความไว 0..maxLevel (ค่อย ๆ ลดลงแบบนุ่มนวล) */
export function beatMsForLevel(level) {
  const lv = Math.max(0, Math.min(RULES.maxLevel, level | 0));
  if (lv === 0) return RULES.maxBeatMs;
  if (lv >= RULES.maxLevel) return RULES.minBeatMs;
  const t = lv / RULES.maxLevel;
  // โค้งแบบ exponential ให้ช่วงแรกค่อย ๆ ไวขึ้นชัดเจน และช่วงท้ายคุมจังหวะสนุก
  const ratio = Math.pow(RULES.minBeatMs / RULES.maxBeatMs, t);
  return Math.round(RULES.maxBeatMs * ratio);
}

/** กรอบเวลาตัดสิน PERFECT และ GOOD (ms) ตามความไวปัจจุบัน */
export function hitWindows(beatMs) {
  const perfect = Math.round(Math.min(85, beatMs * 0.21));
  const good = Math.round(Math.min(175, beatMs * 0.38));
  return { perfect, good };
}

export const TEAM_COLORS = [
  '#ff6a00', '#2b8cff', '#19c37d', '#ffd400',
  '#b56cff', '#ff4d6d', '#19d3d9', '#e2e8f0',
];

export function validateTrack() {
  const problems = [];
  if (RULES.minBeatMs >= RULES.maxBeatMs) problems.push('minBeatMs ต้องน้อยกว่า maxBeatMs');
  if (RULES.minSpeed >= RULES.maxSpeed) problems.push('minSpeed ต้องน้อยกว่า maxSpeed');
  if (TEAM_COLORS.length !== TRACK.lanes) problems.push('จำนวนสีไม่ตรงกับจำนวนลู่วิ่ง');
  return problems;
}
