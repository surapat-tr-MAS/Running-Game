/* สคริปต์เสกบอทเข้าห้องแข่งผ่าน Socket.IO เพื่อซ้อมวิ่งหรือทดสอบโหลด
   วิธีใช้:
     node test/bots.mjs <PIN>            เพิ่มบอท 5 ตัว แล้วเริ่มแข่งทันที
     node test/bots.mjs <PIN> 7 join     เพิ่มบอท 7 ตัว รอโฮสต์กดเริ่มเอง */

import { io } from 'socket.io-client';
import { KEYS, hitWindows } from '../public/shared/track.js';

const PIN = process.argv[2];
const COUNT = Number(process.argv[3] || 5);
const ACTION = process.argv[4] || 'start';
const URL = process.env.RACE_URL || 'http://localhost:3100';

if (!PIN) {
  console.error('ต้องใส่ PIN ของโฮสต์ เช่น: node test/bots.mjs 1234');
  process.exit(1);
}

const NAMES = [
  'บอทสปีด', 'บอทสายลม', 'บอทคอมโบ', 'บอทพุ่ง',
  'บอทพายุ', 'บอทจรวด', 'บอทสายฟ้า', 'บอทชิล',
];

const connect = () =>
  new Promise((res, rej) => {
    const s = io(URL, { transports: ['websocket'] });
    s.once('connect', () => res(s));
    s.once('connect_error', e => rej(new Error('ต่อ ' + URL + ' ไม่ได้: ' + e.message)));
  });
const ask = (s, ev, d) => new Promise(res => s.emit(ev, d, res));

const host = await connect();
const auth = await ask(host, 'host:auth', { pin: PIN });
if (!auth?.ok) {
  console.error('PIN ไม่ถูกต้อง');
  process.exit(1);
}

const bots = [];
for (let i = 0; i < Math.min(COUNT, NAMES.length); i++) {
  const s = await connect();
  const r = await ask(s, 'join', { name: NAMES[i] });
  if (!r?.ok) continue;

  const b = { s, token: r.token, name: r.name, skill: 0.55 + i * 0.05, rhythm: null, playStart: 0, plannedId: 0 };
  s.on('go', d => {
    b.playStart = d.playStartSrvMs;
  });
  s.on('rhythm', d => {
    b.rhythm = d;
    if (!d?.notes?.length || d.finished) return;
    const [id, keyIdx, targetMs] = d.notes[0];
    if (b.plannedId === id) return;
    b.plannedId = id;

    const { perfect, good } = hitWindows(d.beatMs);
    const hitOk = Math.random() < Math.max(0.35, b.skill - d.level * 0.015);
    const delayMs = Math.max(40, targetMs - d.t + (hitOk ? (Math.random() * 2 - 1) * perfect : 0));
    const key = hitOk
      ? KEYS[keyIdx]
      : KEYS.filter((_, idx) => idx !== keyIdx)[Math.floor(Math.random() * 3)];

    setTimeout(() => {
      if (b.rhythm?.finished) return;
      s.emit('tap', { key, at: b.playStart + targetMs });
    }, delayMs);
  });
  bots.push(b);
}
console.log('เพิ่มบอทเข้าห้องแล้ว ' + bots.length + ' ตัว');

if (ACTION === 'join') {
  console.log('บอทพร้อมแล้ว โฮสต์กดแบ่งสายและเริ่มรอบได้ทันที (Ctrl+C เพื่อออก)');
} else {
  await ask(host, 'host:heats', { size: 8 });
  const st = await ask(host, 'host:start', { heat: 0 });
  console.log(st?.ok ? 'เริ่มรอบแล้ว!' : 'เริ่มรอบไม่ได้: ' + st?.msg);
}

process.on('SIGINT', () => {
  for (const b of bots) b.s.close();
  host.close();
  process.exit(0);
});
