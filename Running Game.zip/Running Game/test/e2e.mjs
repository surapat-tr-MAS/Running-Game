/* ทดสอบ End-to-End ครบวงจรของ Running Game
   วิธีใช้: node test/e2e.mjs <PIN> [URL] */

import { io } from 'socket.io-client';
import { KEYS, RULES } from '../public/shared/track.js';

const PIN = process.argv[2];
const URL = process.argv[3] || 'http://localhost:3100';

if (!PIN) {
  console.error('ต้องใส่ PIN: node test/e2e.mjs 1234');
  process.exit(1);
}

const wait = ms => new Promise(r => setTimeout(r, ms));
const connect = () =>
  new Promise((res, rej) => {
    const s = io(URL, { transports: ['websocket'] });
    s.once('connect', () => res(s));
    s.once('connect_error', rej);
  });
const ask = (s, ev, d) => new Promise(res => s.emit(ev, d, res));

let failures = 0;
const check = (ok, label, extra = '') => {
  console.log((ok ? '  OK   ' : '  FAIL ') + label + (extra ? '  ' + extra : ''));
  if (!ok) failures++;
};

/* ---- 1. ตรวจสอบสิทธิ์โฮสต์ ---- */
const host = await connect();
const a = await ask(host, 'host:auth', { pin: PIN });
check(a?.ok, 'โฮสต์เข้าด้วย PIN', a?.msg || '');
if (!a?.ok) process.exit(1);

const wrong = await connect();
const w = await ask(wrong, 'host:auth', { pin: '0000' });
check(!w?.ok, 'PIN ผิดต้องเข้าไม่ได้');
const blk = await ask(wrong, 'host:start', {});
check(!blk?.ok, 'คนไม่มี PIN สั่งเริ่มรอบไม่ได้');
wrong.close();

/* ---- 2. ผู้เล่นเข้าร่วม & ตรวจชื่อ ---- */
const p1Sock = await connect();
const p2Sock = await connect();

const j1 = await ask(p1Sock, 'join', { name: 'นักวิ่งA' });
const j2 = await ask(p2Sock, 'join', { name: 'นักวิ่งB' });
check(j1?.ok && j2?.ok, 'ผู้เล่น 2 คนเข้าร่วมสำเร็จ');

const dupSock = await connect();
const dup = await ask(dupSock, 'join', { name: 'นักวิ่งA' });
check(!dup?.ok, 'ชื่อซ้ำต้องถูกปฏิเสธ');
dupSock.close();

const longSock = await connect();
const longRes = await ask(longSock, 'join', { name: 'ก'.repeat(80) });
check(longRes?.ok && longRes.name.length <= 24, 'ชื่อยาวเกินถูกตัดให้เหลือ <= 24 ตัว', 'ยาว ' + longRes?.name?.length);
longSock.close();

const blankSock = await connect();
const blankRes = await ask(blankSock, 'join', { name: '   ' });
check(!blankRes?.ok, 'ชื่อว่างต้องถูกปฏิเสธ');
blankSock.close();

/* ---- 3. ตั้งระยะทางสั้นสำหรับทดสอบ (100m) + แบ่งสาย + เริ่มรอบ ---- */
const dRes = await ask(host, 'host:distance', { meters: 100 });
check(dRes?.ok, 'ตั้งระยะทางสนามเป็น 100 เมตร');

const botRes = await ask(host, 'host:bots', { count: 2 });
check(botRes?.ok, 'เพิ่มบอทจำลอง 2 ตัว');

const hRes = await ask(host, 'host:heats', { size: 8 });
check(hRes?.ok, 'สุ่มแบ่งสาย');

let p1Rhythm = null;
let p2Rhythm = null;
let playStart = 0;
let goLocalMs = 0;
let finalResult = null;

p1Sock.on('rhythm', d => { p1Rhythm = d; });
p2Sock.on('rhythm', d => { p2Rhythm = d; });
const goPromise = new Promise(res => {
  p1Sock.on('go', d => {
    playStart = d.playStartSrvMs;
    goLocalMs = performance.now();
    res();
  });
});
host.on('result', r => { finalResult = r; });

let p1States = 0;
p1Sock.on('state', () => { p1States++; });

const st = await ask(host, 'host:start', { heat: 0 });
check(st?.ok, 'เริ่มการแข่งขันสาย 1', st?.msg || '');

await Promise.race([goPromise, wait(7000)]);
await wait(40);
check(playStart > 0 && p1Rhythm?.notes?.length > 0, 'เข้าสู่ช่วงวิ่ง (GO) และได้รับชุดโน้ต WASD');

/* ---- 4. ทดสอบกลไกหลัก: กดถูก -> วิ่งเร็วขึ้น + ปุ่มไวขึ้น ---- */
let hitCount = 0;
for (let step = 0; step < 6; step++) {
  const head = p1Rhythm.notes[0];
  const elapsed = performance.now() - goLocalMs;
  const waitMs = Math.max(0, head[2] - elapsed);
  if (waitMs > 0) await wait(waitMs);
  const key = KEYS[head[1]];
  const tapRes = await ask(p1Sock, 'tap', { key, at: playStart + head[2] });
  if (tapRes?.ok && tapRes.judge?.kind !== 'miss') hitCount++;
  await wait(25);
}

check(hitCount >= 5, 'กด WASD ตรงจังหวะต่อเนื่อง', `${hitCount}/6 ครั้ง`);
check(p1Rhythm.level >= 5, 'ความไวปุ่มค่อย ๆ เพิ่มขึ้นตามคอมโบ', `Lv.${p1Rhythm.level + 1}`);
check(p1Rhythm.beatMs < RULES.maxBeatMs, 'ระยะห่างระหว่างปุ่มไวขึ้น', `${p1Rhythm.beatMs}ms < ${RULES.maxBeatMs}ms`);
check(p1Rhythm.speed > RULES.startSpeed, 'ความเร็ววิ่งเพิ่มขึ้น', `${p1Rhythm.speed} m/s > ${RULES.startSpeed} m/s`);

const fastSpeedBeforeMiss = p1Rhythm.speed;
const fastBeatBeforeMiss = p1Rhythm.beatMs;

/* ---- 5. ทดสอบกลไกหลัก: กดพลาด -> ช้าลง + ความไวปุ่ม Reset กลับช้าสุด ---- */
const headForMiss = p1Rhythm.notes[0];
const wrongKey = KEYS.find(k => k !== KEYS[headForMiss[1]]);
const missRes = await ask(p1Sock, 'tap', { key: wrongKey, at: playStart + headForMiss[2] });
await wait(40);

check(missRes?.ok && missRes.judge?.kind === 'miss', 'กดผิดปุ่มต้องถูกตัดสินเป็น MISS');
check(p1Rhythm.speed < fastSpeedBeforeMiss, 'เมื่อพลาด ความเร็ววิ่งต้องลดลง', `${fastSpeedBeforeMiss} -> ${p1Rhythm.speed} m/s`);
check(p1Rhythm.streak === 0 && p1Rhythm.level === 0, 'เมื่อพลาด คอมโบและระดับความไวต้อง Reset เป็น 0');
check(p1Rhythm.beatMs === RULES.maxBeatMs && p1Rhythm.beatMs > fastBeatBeforeMiss,
  'เมื่อพลาด ความไวปุ่มต้อง Reset กลับเป็นช้าสุด', `${fastBeatBeforeMiss}ms -> ${p1Rhythm.beatMs}ms`);

/* ---- 6. ทดสอบการค่อย ๆ ไต่ความเร็วใหม่หลัง Reset และวิ่งเข้าเส้นชัย ---- */
for (let guard = 0; guard < 50 && !p1Rhythm.finished; guard++) {
  const head = p1Rhythm.notes[0];
  if (!head) break;
  const elapsed = performance.now() - goLocalMs;
  const waitMs = Math.max(0, head[2] - elapsed);
  if (waitMs > 0) await wait(waitMs);
  await ask(p1Sock, 'tap', { key: KEYS[head[1]], at: playStart + head[2] });
  await wait(20);
}

check(p1Rhythm.finished === true, 'ผู้เล่นวิ่งเข้าเส้นชัย 100 เมตรสำเร็จ', `เวลา ${p1Rhythm.finishTime}s`);
check(p1States > 80, 'ผู้เล่นได้รับสถานะสนามต่อเนื่อง (~20Hz)', `${p1States} เฟรม`);

/* ---- 7. จบรอบ + ตรวจผลลัพธ์ + ส่งข้อมูลเสีย ---- */
if (!finalResult) {
  await ask(host, 'host:stop', {});
  await wait(250);
}
check(!!finalResult && finalResult.rank.length >= 3, 'ได้รับตารางสรุปผลการแข่งขัน');

p2Sock.emit('tap', null);
p2Sock.emit('tap', { key: 'INVALID', at: 'NaN' });
await wait(200);
check(true, 'เซิร์ฟเวอร์ทนต่อข้อมูลผิดรูปโดยไม่ล่ม');

/* ล้างผู้เล่นทดสอบที่อาจเหลือ */
p1Sock.close();
p2Sock.close();
host.close();

console.log('\n' + (failures ? `ไม่ผ่าน ${failures} ข้อ` : 'ผ่านทั้งหมด!'));
process.exit(failures ? 1 : 0);
