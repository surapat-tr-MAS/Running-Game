/* เซิร์ฟเวอร์เกมวิ่งแข่งจับจังหวะ WASD (Running Game)
   รันบนเครื่องโฮสต์/ครูเครื่องเดียว ผู้เล่นเปิดเบราว์เซอร์เข้ามาที่ IP ของเครื่องนี้
   ไม่ต้องติดตั้งอะไรบนเครื่องผู้เล่น และไม่ต้องใช้อินเทอร์เน็ต */

import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import crypto from 'node:crypto';

import * as G from './src/game.js';
import { BOT_ROSTER, tickBots } from './src/bots.js';
import { TRACK, RULES, TEAM_COLORS, KEYS, KEY_META, validateTrack } from './public/shared/track.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3100;
const SEATS = TRACK.lanes; // 8 ลู่วิ่งต่อรอบ
const HOST_PIN = process.env.HOST_PIN || String(Math.floor(1000 + Math.random() * 9000));
const BOOT_NS = process.hrtime.bigint();
const srvNowMs = () => Number(process.hrtime.bigint() - BOOT_NS) / 1e6;

const problems = validateTrack();
if (problems.length) {
  console.error('ค่ากติกาสนามมีปัญหา:\n  ' + problems.join('\n  '));
  process.exit(1);
}

const app = express();
app.use(express.static(path.join(__dirname, 'public'), { etag: true, maxAge: 0 }));

const http = createServer(app);
const io = new Server(http, { pingInterval: 10000, pingTimeout: 20000 });

/* ---------------- สถานะการแข่ง ---------------- */

const M = {
  phase: 'lobby', // lobby | countdown | playing | result
  trackMeters: TRACK.defaultMeters,
  players: new Map(), // token -> ผู้เล่น
  heats: [],
  heatIndex: -1,
  game: null,
  slotOf: new Map(), // token -> slot (ลู่วิ่ง 0..7)
  countdown: 0,
  lastResult: null,
  roundNo: 0,
};

const newPlayer = (token, name, { isBot = false, skill = 0.75 } = {}) => ({
  token,
  name,
  isBot,
  skill,
  sockets: new Set(),
  total: 0,
  rounds: 0,
  wins: 0,
  bestTime: null,
  heat: -1,
  online: true,
  offlineAt: 0,
});

const playersArr = () => [...M.players.values()];
const byToken = t => M.players.get(t);

function lobbyPayload() {
  return {
    phase: M.phase,
    trackMeters: M.trackMeters,
    roundNo: M.roundNo,
    roundMaxSec: RULES.roundMaxSec,
    seats: SEATS,
    heatIndex: M.heatIndex,
    heats: M.heats,
    lastResult: M.lastResult,
    botCount: playersArr().filter(p => p.isBot).length,
    round:
      M.phase === 'playing' || M.phase === 'countdown'
        ? {
            heatIndex: M.heatIndex,
            trackMeters: M.game?.trackMeters || M.trackMeters,
            playStartSrvMs: M.game?.playStartSrvMs || 0,
            seats: [...M.slotOf].map(([token, slot]) => {
              const p = byToken(token);
              return { slot, token, name: p?.name || '', isBot: !!p?.isBot };
            }),
          }
        : null,
    players: playersArr().map(p => ({
      token: p.token,
      name: p.name,
      isBot: p.isBot,
      total: p.total,
      rounds: p.rounds,
      wins: p.wins,
      bestTime: p.bestTime,
      heat: p.heat,
      online: p.online,
    })),
  };
}

const pushLobby = () => io.emit('lobby', lobbyPayload());

function emitRhythmToPlayer(p, runner) {
  if (!p || !runner || !M.game || p.isBot) return;
  const payload = G.serializeRhythm(M.game, runner);
  for (const sid of p.sockets) {
    io.to(sid).emit('rhythm', payload);
  }
  runner.dirtyRhythm = false;
}

/* ลบผู้เล่นที่หลุดไปนานและยังไม่เคยลงแข่ง (ยกเว้นบอทและคนที่มีคะแนนแล้ว) */
const STALE_MS = 3 * 60 * 1000;
function sweepStale() {
  if (M.phase === 'playing' || M.phase === 'countdown') return 0;
  let removed = 0;
  for (const p of playersArr()) {
    if (p.isBot || p.online || p.rounds > 0) continue;
    if (Date.now() - (p.offlineAt || 0) < STALE_MS) continue;
    M.players.delete(p.token);
    removed++;
  }
  if (removed) {
    M.heats = M.heats.map(h => h.filter(t => M.players.has(t)));
    pushLobby();
  }
  return removed;
}
setInterval(sweepStale, 30000);

function seatSocket(sock) {
  const inRound = M.phase === 'playing' || M.phase === 'countdown';
  const active = inRound && M.slotOf.has(sock.data.token);
  sock.leave(active ? 'spec' : 'active');
  sock.join(active ? 'active' : 'spec');
}

function reseatAll() {
  for (const s of io.sockets.sockets.values()) seatSocket(s);
}

/* ---------------- วงจรของรอบ ---------------- */

function startHeat(index) {
  const heat = M.heats[index];
  if (!heat || !heat.length) return 'สายนี้ไม่มีผู้เล่น';

  const roster = heat.map(byToken).filter(p => p && p.online).slice(0, SEATS);
  if (!roster.length) return 'ผู้เล่นในสายนี้ออฟไลน์ทั้งหมด';

  M.heatIndex = index;
  M.game = G.createGame({ trackMeters: M.trackMeters });
  M.slotOf.clear();

  roster.forEach((p, i) => {
    const r = G.addRunner(M.game, {
      id: i + 1,
      token: p.token,
      name: p.name,
      slot: i,
      isBot: p.isBot,
      skill: p.skill,
    });
    M.slotOf.set(p.token, i);
    r.dirtyRhythm = true;
  });

  M.phase = 'countdown';
  M.countdown = RULES.countdownSec;
  lastCountdown = -1;
  M.lastResult = null;

  io.emit('begin', {
    heatIndex: index,
    trackMeters: M.game.trackMeters,
    seats: roster.map((p, i) => ({ slot: i, name: p.name, token: p.token, isBot: p.isBot })),
  });
  reseatAll();
  for (const r of M.game.runners) {
    emitRhythmToPlayer(byToken(r.token), r);
  }
  pushLobby();
  return null;
}

function endRound(reason) {
  if (!M.game) return;
  const finishReason =
    reason || (M.game.finishCount >= M.game.runners.length ? 'เข้าเส้นชัยครบทุกคน!' : 'หมดเวลาการแข่งขัน');
  const rank = G.finish(M.game);

  for (const row of rank) {
    const p = row.token ? byToken(row.token) : null;
    if (!p) continue;
    p.total += row.score;
    p.rounds += 1;
    if (row.rank === 1 && row.finished) p.wins += 1;
    if (row.finishTime !== null && (p.bestTime === null || row.finishTime < p.bestTime)) {
      p.bestTime = row.finishTime;
    }
  }

  M.lastResult = {
    heatIndex: M.heatIndex,
    trackMeters: M.game.trackMeters,
    reason: finishReason,
    rank,
  };
  M.roundNo += 1;
  M.phase = 'result';
  M.game = null;

  reseatAll();
  io.emit('result', M.lastResult);
  pushLobby();
}

/* ---------------- ลูปหลัก (Fixed Timestep Accumulator) ---------------- */

const dt = 1 / RULES.tickHz;
const MAX_CATCHUP = 4;
let tickNo = 0;
let lastCountdown = -1;
let acc = 0;
let prevNs = process.hrtime.bigint();

setInterval(() => {
  const now = process.hrtime.bigint();
  acc += Number(now - prevNs) / 1e9;
  prevNs = now;
  if (acc > dt * MAX_CATCHUP) acc = dt * MAX_CATCHUP;
  while (acc >= dt) {
    acc -= dt;
    stepOnce();
  }
}, 5);

function stepOnce() {
  tickNo++;

  if (M.phase === 'countdown') {
    M.countdown -= dt;
    const n = Math.max(0, Math.ceil(M.countdown));
    if (n !== lastCountdown) {
      lastCountdown = n;
      io.emit('countdown', n);
    }
    if (M.countdown <= 0 && M.game) {
      M.phase = 'playing';
      M.game.playStartSrvMs = Math.round(srvNowMs());
      io.emit('go', {
        playStartSrvMs: M.game.playStartSrvMs,
        trackMeters: M.game.trackMeters,
      });
      for (const r of M.game.runners) {
        emitRhythmToPlayer(byToken(r.token), r);
      }
      reseatAll();
      pushLobby();
    }
    return;
  }

  if (M.phase !== 'playing' || !M.game) return;

  tickBots(M.game);
  G.tick(M.game, dt);

  for (const r of M.game.runners) {
    if (r.dirtyRhythm) {
      emitRhythmToPlayer(byToken(r.token), r);
    }
  }

  const snap = G.serializeTrack(M.game);
  io.to('active').emit('state', snap);
  if (tickNo % 2 === 0) io.to('spec').emit('state', snap);

  if (M.game.over) endRound();
}

/* ---------------- การเชื่อมต่อ Socket.IO ---------------- */

io.on('connection', sock => {
  let me = null;
  let isHost = false;

  sock.emit('hello', {
    rules: RULES,
    track: TRACK,
    keys: KEYS,
    keyMeta: KEY_META,
    colors: TEAM_COLORS,
    srvMs: Math.round(srvNowMs()),
    lobby: lobbyPayload(),
  });
  sock.join('spec');

  /* ซิงค์นาฬิกาเพื่อให้ตัวโน้ตลื่นตรงกันบนทุกเครื่อง */
  sock.on('time:ping', (t0, ack) => {
    if (typeof ack === 'function') {
      ack({ t0, srvMs: Math.round(srvNowMs()) });
    }
  });

  /* ผู้เล่นเข้าร่วม */
  sock.on('join', (d, ack) => {
    const name = String(d?.name || '').trim().slice(0, 24);
    if (!name) return ack?.({ ok: false, msg: 'กรุณาใส่ชื่อผู้เล่น' });

    let token = typeof d?.token === 'string' ? d.token : '';
    let p = token && byToken(token);

    if (p && !p.isBot) {
      p.name = name;
    } else {
      const dup = playersArr().some(q => q.name === name && q.online);
      if (dup) return ack?.({ ok: false, msg: 'ชื่อนี้มีคนใช้แล้ว ลองเติมตัวเลขหรือชื่อเล่นเพิ่ม' });
      token = crypto.randomUUID();
      p = newPlayer(token, name);
      M.players.set(token, p);
    }

    p.online = true;
    p.sockets.add(sock.id);
    me = p;
    sock.data.token = token;
    seatSocket(sock);

    const slot = M.slotOf.get(token);
    ack?.({ ok: true, token, name, slot: slot ?? null });

    if ((M.phase === 'playing' || M.phase === 'countdown') && M.game && slot !== undefined) {
      const runner = M.game.runners.find(r => r.slot === slot);
      if (runner) emitRhythmToPlayer(p, runner);
    }
    pushLobby();
  });

  /* กดปุ่ม WASD จับจังหวะ */
  sock.on('tap', (d, ack) => {
    if (!me || M.phase !== 'playing' || !M.game) return;
    const slot = M.slotOf.get(me.token);
    if (slot === undefined) return;
    const runner = M.game.runners.find(r => r.slot === slot);
    if (!runner) return;

    const judge = G.handleTap(M.game, runner, d?.key, Number(d?.at));
    if (judge) {
      emitRhythmToPlayer(me, runner);
      ack?.({ ok: true, judge });
    } else {
      ack?.({ ok: false });
    }
  });

  sock.on('spectate', () => {
    sock.leave('active');
    sock.join('spec');
  });

  /* ----- ฝั่งโฮสต์ / ครู ----- */
  sock.on('host:auth', (d, ack) => {
    if (String(d?.pin || '') !== HOST_PIN) return ack?.({ ok: false, msg: 'PIN ไม่ถูกต้อง' });
    isHost = true;
    ack?.({ ok: true, lobby: lobbyPayload(), pin: HOST_PIN });
  });

  const host = fn => (d, ack) => {
    if (!isHost) return ack?.({ ok: false, msg: 'ต้องใส่ PIN ของโฮสต์ก่อน' });
    const msg = fn(d);
    ack?.(msg ? { ok: false, msg } : { ok: true });
  };

  sock.on(
    'host:distance',
    host(d => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'เปลี่ยนระยะทางระหว่างแข่งไม่ได้';
      const meters = Math.round(Number(d?.meters));
      if (!Number.isFinite(meters) || meters < TRACK.minMeters || meters > TRACK.maxMeters) {
        return `ระยะทางต้องอยู่ระหว่าง ${TRACK.minMeters}-${TRACK.maxMeters} เมตร`;
      }
      M.trackMeters = meters;
      pushLobby();
    }),
  );

  sock.on(
    'host:bots',
    host(d => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'เพิ่มหรือลบบอทระหว่างแข่งไม่ได้';
      const count = Math.max(0, Math.min(BOT_ROSTER.length, Number(d?.count) || 0));

      // ลบบอทเดิมออกก่อนแล้วตั้งจำนวนบอทใหม่ให้เรียบร้อย
      for (const p of playersArr()) {
        if (p.isBot) M.players.delete(p.token);
      }
      for (let i = 0; i < count; i++) {
        const spec = BOT_ROSTER[i];
        const token = 'bot-' + (i + 1);
        M.players.set(token, newPlayer(token, spec.name, { isBot: true, skill: spec.skill }));
      }
      M.heats = M.heats.map(h => h.filter(t => M.players.has(t))).filter(h => h.length);
      M.heatIndex = -1;
      pushLobby();
    }),
  );

  sock.on(
    'host:heats',
    host(d => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'กำลังแข่งอยู่';
      const size = Math.min(SEATS, Math.max(1, Number(d?.size) || SEATS));
      const pool = playersArr().filter(p => p.online);
      if (!pool.length) return 'ยังไม่มีผู้เล่นเข้าร่วม (กดเพิ่มบอทหรือรอผู้เล่นเข้ามาก่อน)';

      for (let i = pool.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
      }
      M.heats = [];
      for (let i = 0; i < pool.length; i += size) {
        M.heats.push(pool.slice(i, i + size).map(p => p.token));
      }
      playersArr().forEach(p => {
        p.heat = -1;
      });
      M.heats.forEach((h, i) =>
        h.forEach(t => {
          const p = byToken(t);
          if (p) p.heat = i;
        }),
      );
      M.heatIndex = -1;
      pushLobby();
    }),
  );

  sock.on(
    'host:final',
    host(d => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'กำลังแข่งอยู่';
      const n = Math.min(SEATS, Math.max(1, Number(d?.n) || SEATS));
      const top = playersArr()
        .filter(p => p.online && p.rounds > 0)
        .sort((a, b) => b.total - a.total || (a.bestTime ?? 9999) - (b.bestTime ?? 9999))
        .slice(0, n);
      if (!top.length) return 'ต้องแข่งรอบคัดเลือกอย่างน้อย 1 รอบก่อน';
      M.heats = [top.map(p => p.token)];
      playersArr().forEach(p => {
        p.heat = -1;
      });
      top.forEach(p => {
        p.heat = 0;
      });
      M.heatIndex = -1;
      pushLobby();
    }),
  );

  sock.on(
    'host:start',
    host(d => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'กำลังแข่งอยู่';
      const idx = Number.isInteger(d?.heat) ? d.heat : M.heatIndex + 1;
      if (!M.heats.length) return 'ยังไม่ได้แบ่งสาย';
      const targetIdx = idx >= 0 && idx < M.heats.length ? idx : 0;
      return startHeat(targetIdx);
    }),
  );

  sock.on(
    'host:stop',
    host(() => {
      if (M.phase === 'playing') endRound('โฮสต์สั่งจบรอบ');
      else {
        M.phase = 'lobby';
        M.game = null;
        M.countdown = 0;
        reseatAll();
        pushLobby();
      }
    }),
  );

  sock.on(
    'host:lobby',
    host(() => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'กำลังแข่งอยู่';
      M.phase = 'lobby';
      pushLobby();
    }),
  );

  sock.on(
    'host:reset',
    host(() => {
      if (M.phase === 'playing' || M.phase === 'countdown') return 'กำลังแข่งอยู่';
      playersArr().forEach(p => {
        p.total = 0;
        p.rounds = 0;
        p.wins = 0;
        p.bestTime = null;
        p.heat = -1;
      });
      M.heats = [];
      M.heatIndex = -1;
      M.roundNo = 0;
      M.lastResult = null;
      pushLobby();
    }),
  );

  sock.on(
    'host:kick',
    host(d => {
      const p = byToken(String(d?.token || ''));
      if (!p) return 'ไม่พบผู้เล่นคนนี้';
      for (const sid of p.sockets) io.sockets.sockets.get(sid)?.disconnect(true);
      M.players.delete(p.token);
      M.heats = M.heats.map(h => h.filter(t => t !== p.token)).filter(h => h.length);
      pushLobby();
    }),
  );

  sock.on(
    'host:sweep',
    host(() => {
      let removed = 0;
      for (const p of playersArr()) {
        if (p.isBot || p.online || p.rounds > 0) continue;
        M.players.delete(p.token);
        removed++;
      }
      M.heats = M.heats.map(h => h.filter(t => M.players.has(t))).filter(h => h.length);
      pushLobby();
      if (!removed) return 'ไม่มีรายชื่อค้างให้ลบ';
    }),
  );

  sock.on('disconnect', () => {
    if (!me) return;
    me.sockets.delete(sock.id);
    if (!me.sockets.size) {
      me.online = false;
      me.offlineAt = Date.now();
      setTimeout(() => {
        if (!me.sockets.size) pushLobby();
      }, 1000);
    }
    pushLobby();
  });
});

/* ---------------- หา IP ในเครือข่ายจริง (คัดการ์ดเสมือนออก) ---------------- */

const VIRTUAL_RE = /virtualbox|vmware|hyper-v|vethernet|wsl|loopback|bluetooth|tailscale|zerotier|npcap|tap-|docker/i;

function lanIPs() {
  const out = [];
  for (const [name, addrs] of Object.entries(os.networkInterfaces())) {
    for (const a of addrs || []) {
      if (!a || a.family !== 'IPv4' || a.internal) continue;
      if (a.address.startsWith('169.254.')) continue;
      let score = 0;
      if (VIRTUAL_RE.test(name)) score -= 10;
      if (a.address.startsWith('192.168.56.')) score -= 8;
      if (/wi-?fi|wireless|wlan/i.test(name)) score += 3;
      if (/ethernet|lan/i.test(name) && !VIRTUAL_RE.test(name)) score += 4;
      out.push({ ip: a.address, name, score });
    }
  }
  return out.sort((a, b) => b.score - a.score);
}

http.listen(PORT, () => {
  const all = lanIPs();
  const usable = all.filter(i => i.score >= 0);
  const best = usable[0] || all[0] || null;
  const others = all.filter(i => i !== best);
  const line = '='.repeat(60);

  console.log('\n' + line);
  console.log('  Running Game — เกมวิ่งแข่งจับจังหวะ WASD');
  console.log(line);

  if (best) {
    console.log('\n  ลิงก์สำหรับผู้เล่น (เปิดในเบราว์เซอร์):\n');
    console.log('      http://' + best.ip + ':' + PORT);
    console.log('\n  จอควบคุมของโฮสต์ / โปรเจกเตอร์ (เปิดในเครื่องนี้):\n');
    console.log('      http://localhost:' + PORT + '/host.html');
    console.log('\n  PIN สำหรับจอควบคุม:  ' + HOST_PIN);

    if (others.length) {
      console.log('\n  ' + '-'.repeat(56));
      console.log('  หากเข้าด้วยลิงก์ด้านบนไม่ได้ ลองอันอื่นในรายการนี้:');
      for (const o of others) {
        const tag = o.score < 0 ? '   (การ์ดเสมือน มักใช้ไม่ได้)' : '';
        console.log('      http://' + o.ip + ':' + PORT + '   [' + o.name + ']' + tag);
      }
    }
  } else {
    console.log('\n  ไม่พบเครือข่าย LAN/WiFi — ทดลองเล่นในเครื่องนี้ได้ที่:\n');
    console.log('      http://localhost:' + PORT);
    console.log('      http://localhost:' + PORT + '/host.html');
    console.log('\n  PIN สำหรับจอควบคุม:  ' + HOST_PIN);
  }

  console.log('\n  *** อย่าปิดหน้าต่างนี้ระหว่างเล่น ***');
  console.log(line + '\n');
});
