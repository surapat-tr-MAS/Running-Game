/* ระบบบอทนักวิ่งจำลองในตัวเซิร์ฟเวอร์ (ครู/โฮสต์กดเพิ่มได้จากจอควบคุมเพื่อซ้อมเล่นคนเดียวหรือเติมสาย) */

import { KEYS, hitWindows } from '../public/shared/track.js';
import { handleTap } from './game.js';

export const BOT_ROSTER = [
  { name: 'บอทสายฟ้า', skill: 0.90 },
  { name: 'บอทสปีด', skill: 0.84 },
  { name: 'บอทจังหวะ', skill: 0.78 },
  { name: 'บอทพายุ', skill: 0.72 },
  { name: 'บอทเต่าซิ่ง', skill: 0.64 },
  { name: 'บอทซิกแซ็ก', skill: 0.56 },
  { name: 'บอทน้องใหม่', skill: 0.48 },
];

/** ให้บอทวางแผนกดโน้ตถัดไปและส่งคำสั่งเมื่อถึงเวลา */
export function tickBots(g) {
  if (!g || g.over) return;
  const elapsedMs = g.t * 1000;

  for (const r of g.runners) {
    if (!r.isBot || r.finished) continue;
    const head = r.notes[0];
    if (!head) continue;

    if (r.botNextPlanNoteId !== head.id) {
      r.botNextPlanNoteId = head.id;
      const { perfect, good } = hitWindows(r.beatMs);
      // ยิ่งความเร็วปุ่มสูงขึ้น บอทยิ่งมีโอกาสพลาดมากขึ้นตามทักษะของตัวบอทเอง
      const pressure = r.tempoLevel * 0.015;
      const hitChance = Math.max(0.35, r.skill - pressure);

      if (Math.random() < hitChance) {
        const isPerf = Math.random() < r.skill * 0.72;
        const spread = isPerf ? perfect * 0.75 : good * 0.85;
        const offset = (Math.random() * 2 - 1) * spread;
        r.botPlanMs = Math.max(elapsedMs + 20, head.targetMs + offset);
        r.botPlanKey = head.key;
      } else {
        // ตั้งใจพลาด (กดผิดปุ่มหรือกดช้าเกิน) เพื่อให้เห็นการ Reset จังหวะเหมือนคนจริง
        if (Math.random() < 0.65) {
          const others = KEYS.filter(k => k !== head.key);
          r.botPlanKey = others[Math.floor(Math.random() * others.length)];
          r.botPlanMs = Math.max(elapsedMs + 30, head.targetMs + (Math.random() * 2 - 1) * good * 0.5);
        } else {
          r.botPlanKey = null; // ปล่อยหลุดจังหวะ
          r.botPlanMs = Infinity;
        }
      }
    }

    if (r.botPlanKey && elapsedMs >= r.botPlanMs) {
      const k = r.botPlanKey;
      r.botPlanKey = null;
      handleTap(g, r, k, null);
    }
  }
}
