/* เอนจินเกมวิ่งแข่งจับจังหวะ WASD — คำนวณบนเซิร์ฟเวอร์เท่านั้น (server authoritative)
   - กด WASD ตรงจังหวะ: วิ่งเร็วขึ้น + จังหวะปุ่มค่อย ๆ ไวขึ้นทีละขั้น
   - กดพลาดหรือปล่อยหลุดจังหวะ: วิ่งช้าลง + ความไวปุ่ม Reset กลับเป็นช้าสุดทันที */

import { KEYS, TRACK, RULES, beatMsForLevel, hitWindows } from '../public/shared/track.js';

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

/** สุ่มลำดับปุ่มแบบ deterministic ต่อรอบ เพื่อให้ผู้เล่นทุกคนเจอชุดโน้ตที่เป็นธรรมเหมือนกัน */
function makeRng(seed) {
  let s = (seed >>> 0) || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function keyAt(g, idx) {
  while (g.noteSeq.length <= idx) {
    const n = g.noteSeq.length;
    let k = KEYS[Math.floor(g.rng() * KEYS.length)];
    // กันสุ่มได้ปุ่มเดิมติดกันเกิน 2 ครั้ง เพื่อให้จังหวะสนุกและหลากหลาย
    if (n >= 2 && g.noteSeq[n - 1] === k && g.noteSeq[n - 2] === k) {
      const alt = KEYS.filter(x => x !== k);
      k = alt[Math.floor(g.rng() * alt.length)];
    }
    g.noteSeq.push(k);
  }
  return g.noteSeq[idx];
}

function pushNextNote(g, r, targetMs) {
  const key = keyAt(g, r.seqIndex++);
  r.notes.push({ id: r.nextNoteId++, key, targetMs: Math.round(targetMs) });
}

function fillQueue(g, r, startMs) {
  let cursor = startMs;
  if (r.notes.length) {
    cursor = r.notes[r.notes.length - 1].targetMs + r.beatMs;
  }
  while (r.notes.length < 5) {
    pushNextNote(g, r, cursor);
    cursor += r.beatMs;
  }
}

export function createGame(opts = {}) {
  const trackMeters = clamp(
    Number(opts.trackMeters) || TRACK.defaultMeters,
    TRACK.minMeters,
    TRACK.maxMeters,
  );
  const seed = (Number(opts.seed) || Math.floor(Math.random() * 0x7fffffff)) >>> 0;
  return {
    trackMeters,
    seed,
    rng: makeRng(seed),
    noteSeq: [],
    t: 0,
    playStartSrvMs: Number(opts.playStartSrvMs) || 0,
    runners: [],
    finishCount: 0,
    over: false,
  };
}

export function addRunner(g, { id, name, slot, token, isBot = false, skill = 0.75 }) {
  const r = {
    id,
    token: token || null,
    name,
    slot,
    isBot,
    skill,
    dist: 0,
    speed: RULES.startSpeed,
    streak: 0,
    maxStreak: 0,
    tempoLevel: 0,
    beatMs: beatMsForLevel(0),
    perfects: 0,
    goods: 0,
    misses: 0,
    score: 0,
    finished: false,
    finishTime: 0,
    place: 0,
    seqIndex: 0,
    nextNoteId: 1,
    notes: [],
    lockoutUntilMs: 0,
    stumbleUntilMs: -1,
    lastHitAtMs: 0,
    judgeSeq: 0,
    lastJudge: null,
    dirtyRhythm: true,
    botNextPlanNoteId: 0,
    botPlanMs: 0,
    botPlanKey: null,
  };
  fillQueue(g, r, RULES.leadInMs);
  g.runners.push(r);
  return r;
}

function applyHit(g, r, kind, judgeMs, diff) {
  const head = r.notes.shift();
  r.streak += 1;
  if (r.streak > r.maxStreak) r.maxStreak = r.streak;
  if (kind === 'perfect') r.perfects += 1;
  else r.goods += 1;

  r.tempoLevel = Math.min(RULES.maxLevel, r.streak);
  r.beatMs = beatMsForLevel(r.tempoLevel);
  r.lastHitAtMs = judgeMs;

  // กดตรงจังหวะ -> วิ่งเร็วขึ้นตามระดับความไว + แรงส่งจากจังหวะนี้
  const tierTarget =
    RULES.startSpeed + (RULES.maxSpeed - RULES.startSpeed) * (r.tempoLevel / RULES.maxLevel);
  if (kind === 'perfect') {
    r.speed = Math.min(RULES.maxSpeed, Math.max(r.speed + 1.35, tierTarget));
    r.score += 12 + Math.min(24, r.streak * 2);
  } else {
    r.speed = Math.min(RULES.maxSpeed, Math.max(r.speed + 0.85, tierTarget - 0.6));
    r.score += 7 + Math.min(14, r.streak);
  }

  // จัดตารางโน้ตถัดไปบนกริดจังหวะใหม่ที่ไวขึ้น (กันทับช่วงกดทันที)
  const { good: nextGood } = hitWindows(r.beatMs);
  let cursor = Math.max(judgeMs + nextGood + 70, head.targetMs + r.beatMs);
  for (let i = 0; i < r.notes.length; i++) {
    r.notes[i].targetMs = Math.round(cursor);
    cursor += r.beatMs;
  }
  fillQueue(g, r, cursor);

  r.judgeSeq += 1;
  r.lastJudge = {
    seq: r.judgeSeq,
    kind,
    diff: Math.round(diff),
    key: head.key,
    atMs: Math.round(judgeMs),
  };
  r.dirtyRhythm = true;
  return r.lastJudge;
}

function applyMiss(g, r, judgeMs, reason, pressedKey) {
  r.streak = 0;
  r.tempoLevel = 0;
  r.beatMs = beatMsForLevel(0);                          // Reset ความไวปุ่มกลับเป็นช้าสุด
  r.misses += 1;
  r.speed = Math.max(RULES.minSpeed, r.speed * RULES.missSpeedKeep); // วิ่งช้าลงทันที
  r.stumbleUntilMs = judgeMs + 550;
  r.lockoutUntilMs = judgeMs + RULES.missLockoutMs;

  // ล้างโน้ตเก่าที่พลาด แล้วเริ่มชุดใหม่ในจังหวะช้าสุดเพื่อให้ผู้เล่นตั้งหลักใหม่ได้
  r.notes.length = 0;
  fillQueue(g, r, Math.round(judgeMs + RULES.maxBeatMs));

  r.judgeSeq += 1;
  r.lastJudge = {
    seq: r.judgeSeq,
    kind: 'miss',
    reason,
    key: pressedKey || null,
    atMs: Math.round(judgeMs),
  };
  r.dirtyRhythm = true;
  return r.lastJudge;
}

/** รับการกดปุ่มจากผู้เล่น (หรือบอท) และตัดสินผลจังหวะ */
export function handleTap(g, r, rawKey, clientSrvMs = null) {
  if (!g || !r || g.over || r.finished) return null;
  const key = typeof rawKey === 'string' ? rawKey.toUpperCase() : '';
  if (!KEYS.includes(key)) return null;

  const elapsedMs = g.t * 1000;
  let judgeMs = elapsedMs;
  if (Number.isFinite(clientSrvMs) && g.playStartSrvMs > 0) {
    const raw = clientSrvMs - g.playStartSrvMs;
    judgeMs = clamp(raw, elapsedMs - 220, elapsedMs + 40);
  }
  if (judgeMs < r.lockoutUntilMs) return null;

  const head = r.notes[0];
  if (!head) return null;

  const diff = judgeMs - head.targetMs;
  const absDiff = Math.abs(diff);
  const { perfect, good } = hitWindows(r.beatMs);

  if (key === head.key && absDiff <= perfect) {
    return applyHit(g, r, 'perfect', judgeMs, diff);
  }
  if (key === head.key && absDiff <= good) {
    return applyHit(g, r, 'good', judgeMs, diff);
  }

  const reason = key !== head.key ? 'wrong' : diff < 0 ? 'early' : 'late';
  return applyMiss(g, r, judgeMs, reason, key);
}

/** เดินเกม 1 tick */
export function tick(g, dt) {
  if (g.over) return;
  g.t += dt;
  const elapsedMs = g.t * 1000;

  let allDone = g.runners.length > 0;
  for (const r of g.runners) {
    if (r.finished) continue;
    allDone = false;

    const head = r.notes[0];
    if (head) {
      const { good } = hitWindows(r.beatMs);
      if (elapsedMs > head.targetMs + good + RULES.latencyGraceMs) {
        applyMiss(g, r, head.targetMs + good, 'timeout', null);
      }
    }

    // แรงเฉื่อยลดระดับลงเบา ๆ หากห่างจากการกดนานเกิน 1 จังหวะ
    if (r.speed > RULES.cruiseFloor && elapsedMs - r.lastHitAtMs > r.beatMs + 150) {
      r.speed = Math.max(RULES.cruiseFloor, r.speed - RULES.dragPerSec * dt);
    }

    const prevDist = r.dist;
    const nextDist = prevDist + r.speed * dt;
    if (nextDist >= g.trackMeters) {
      const frac = clamp((g.trackMeters - prevDist) / Math.max(1e-6, nextDist - prevDist), 0, 1);
      r.dist = g.trackMeters;
      r.finished = true;
      g.finishCount += 1;
      r.place = g.finishCount;
      r.finishTime = (g.t - dt) + dt * frac;
      r.score += RULES.placeBonus[r.place - 1] ?? 10;
      r.dirtyRhythm = true;
    } else {
      r.dist = nextDist;
    }
  }

  if (allDone || g.t >= RULES.roundMaxSec) {
    finish(g);
  }
}

export function finish(g) {
  if (g.over) return standings(g);
  g.over = true;
  return standings(g);
}

export function standings(g) {
  return [...g.runners]
    .sort((a, b) => {
      if (a.finished !== b.finished) return a.finished ? -1 : 1;
      if (a.finished && b.finished) return a.finishTime - b.finishTime;
      return b.dist - a.dist || b.score - a.score;
    })
    .map((r, idx) => {
      const total = r.perfects + r.goods + r.misses;
      const accuracy = total > 0 ? Math.round(((r.perfects + r.goods * 0.7) / total) * 100) : 0;
      return {
        id: r.id,
        token: r.token,
        name: r.name,
        slot: r.slot,
        isBot: r.isBot,
        rank: idx + 1,
        finished: r.finished,
        finishTime: r.finished ? +r.finishTime.toFixed(2) : null,
        dist: +r.dist.toFixed(1),
        speed: +r.speed.toFixed(1),
        score: r.score,
        perfects: r.perfects,
        goods: r.goods,
        misses: r.misses,
        maxStreak: r.maxStreak,
        accuracy,
      };
    });
}

const q = v => Math.round(v * 50);

/** ย่อข้อมูลลู่วิ่งสำหรับ broadcast ให้ทุกคน (20Hz ผู้เล่น / 10Hz ผู้ชม) */
export function serializeTrack(g) {
  const elapsedMs = g.t * 1000;
  const sorted = [...g.runners].sort((a, b) => {
    if (a.finished !== b.finished) return a.finished ? -1 : 1;
    if (a.finished && b.finished) return a.finishTime - b.finishTime;
    return b.dist - a.dist;
  });
  const rankOf = new Map(sorted.map((r, i) => [r.slot, i + 1]));

  return {
    t: Math.round(elapsedMs),
    m: g.trackMeters,
    r: g.runners.map(r => [
      r.slot,
      q(r.dist),
      q(r.speed),
      r.streak,
      r.tempoLevel,
      (r.finished ? 1 : 0) |
        (elapsedMs < r.stumbleUntilMs ? 2 : 0) |
        (r.tempoLevel >= 8 ? 4 : 0),
      r.finished ? Math.round(r.finishTime * 1000) : 0,
      rankOf.get(r.slot) || 0,
    ]),
  };
}

/** ข้อมูลจังหวะส่วนตัวของนักวิ่ง 1 คน */
export function serializeRhythm(g, r) {
  return {
    t: Math.round(g.t * 1000),
    streak: r.streak,
    maxStreak: r.maxStreak,
    level: r.tempoLevel,
    beatMs: r.beatMs,
    speed: +r.speed.toFixed(2),
    dist: +r.dist.toFixed(2),
    score: r.score,
    finished: r.finished,
    place: r.place,
    finishTime: r.finished ? +r.finishTime.toFixed(2) : null,
    judge: r.lastJudge,
    notes: r.notes.map(n => [n.id, KEYS.indexOf(n.key), n.targetMs]),
  };
}
