/* คัดลอก three.js จาก node_modules มาไว้ใน public/vendor
   เพื่อให้เกมเล่นได้โดยไม่ต้องโหลดไลบรารีจากอินเทอร์เน็ต
   รันเมื่ออัปเกรดเวอร์ชัน three: npm run vendor */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const FILES = [
  ['node_modules/three/build/three.module.js', 'public/vendor/three.module.js'],
];

let copied = 0;
for (const [from, to] of FILES) {
  const src = path.join(root, from);
  const dst = path.join(root, to);
  if (!fs.existsSync(src)) {
    console.error('ไม่พบ ' + from + ' — ลองรัน npm install ก่อน');
    process.exit(1);
  }
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  console.log('คัดลอก ' + to + ' (' + Math.round(fs.statSync(dst).size / 1024) + ' KB)');
  copied++;
}
console.log('เสร็จแล้ว ' + copied + ' ไฟล์');
