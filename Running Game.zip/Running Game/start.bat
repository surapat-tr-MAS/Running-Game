@echo off
chcp 65001 >nul
title Running Game - เกมวิ่งแข่งจับจังหวะ WASD
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [ไม่พบ Node.js]
  echo.
  echo เครื่องนี้ยังไม่ได้ติดตั้ง Node.js ซึ่งจำเป็นต้องใช้รันเกม
  echo   1. เข้า https://nodejs.org
  echo   2. ดาวน์โหลดรุ่น LTS แล้วติดตั้งตามปกติ
  echo   3. ปิดหน้าต่างนี้ แล้วดับเบิลคลิก start.bat อีกครั้ง
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\express" (
  echo กำลังติดตั้งส่วนประกอบครั้งแรก กรุณารอสักครู่...
  call npm.cmd install --omit=dev
  if errorlevel 1 (
    echo.
    echo ติดตั้งไม่สำเร็จ - ตรวจสอบว่าเครื่องต่ออินเทอร์เน็ตอยู่หรือไม่
    pause
    exit /b 1
  )
  echo.
)

node server.js

echo.
echo ============================================================
echo   เซิร์ฟเวอร์หยุดทำงานแล้ว
echo ============================================================
echo กดปุ่มใดก็ได้เพื่อปิดหน้าต่าง
pause >nul
